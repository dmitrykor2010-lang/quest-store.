# QUEST STORE

A Russian-language shared rewards shop for a Telegram quest team. Players see one server-backed team balance and the same character unlock states; only the verified author can edit the shared catalog.

## Run & Operate

- `pnpm --filter @workspace/api-server run dev` — run the API server (port 5000)
- `pnpm run typecheck` — full typecheck across all packages
- `pnpm run build` — typecheck + build all packages
- `pnpm --filter @workspace/api-spec run codegen` — regenerate API hooks and Zod schemas from the OpenAPI spec
- `pnpm --filter @workspace/db run push` — push DB schema changes (dev only)
- Required env: `DATABASE_URL` — Postgres connection string; `QUEST_STORE_ADMIN_EMAIL` — verified primary email allowed to administer the shop
- Clerk sign-in keys are provisioned by Replit and must never be copied into client code or committed files.

## Stack

- pnpm workspaces, Node.js 24, TypeScript 5.9
- API: Express 5
- DB: PostgreSQL + Drizzle ORM
- Validation: Zod (`zod/v4`), `drizzle-zod`
- API codegen: Orval (from OpenAPI spec)
- Build: esbuild (CJS bundle)

## Where things live

- `artifacts/quest-store` — Russian mobile-first storefront and protected author panel
- `artifacts/api-server/src/routes/quest-store.ts` — public shared snapshot and author-only mutations
- `lib/db/src/schema/quest-store.ts` — persistent points, character, and reward tables
- `lib/api-spec/openapi.yaml` — source of truth for the store API

## Architecture decisions

- Players have no purchase or mutation endpoints; the public API is read-only.
- Author access requires Clerk authentication, a verified primary email match on the server, and same-origin mutation requests.
- The author email is server-side configuration only; an unset value denies admin access.

## Product

- Shared team points, character catalog with locked/unlocked status, and special rewards.
- Author-only controls for the shared balance, character details/status/images, and reward details/images.
- Shop UI and sign-in screens are in Russian; the public catalog is usable without signing in.

## User preferences

- Preserve the black/deep-blue fantasy atmosphere, mist, glowing cyan details, and mobile-first Android usability.

## Gotchas

_Populate as you build — sharp edges, "always run X before Y" rules._

## Pointers

- See the `pnpm-workspace` skill for workspace structure, TypeScript setup, and package details

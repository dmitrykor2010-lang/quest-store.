import { createInsertSchema } from "drizzle-zod";
import { sql } from "drizzle-orm";
import { integer, jsonb, pgTable, text, timestamp } from "drizzle-orm/pg-core";
import { z } from "zod/v4";

export type StoreDesignSettings = {
  primaryColor: string;
  backgroundColor: string;
  bodyTextColor: string;
  headingColor: string;
  numberColor: string;
  buttonColor: string;
  buttonTextColor: string;
  cardColor: string;
  borderColor: string;
  accentColor: string;
  fontFamily: "default" | "system" | "serif" | "mono" | "rounded";
  fontWeight: number;
  headingSize: number;
  bodySize: number;
  textStyle: "normal" | "italic" | "wide";
  backgroundDim: number;
  tintColor: string;
  tintOpacity: number;
  cardOpacity: number;
};

export const DEFAULT_STORE_DESIGN_SETTINGS: StoreDesignSettings = {
  primaryColor: "#53D9E3",
  backgroundColor: "#080D17",
  bodyTextColor: "#94A3B8",
  headingColor: "#F1F5F9",
  numberColor: "#67E8F9",
  buttonColor: "#53D9E3",
  buttonTextColor: "#07121B",
  cardColor: "#0F1927",
  borderColor: "#365366",
  accentColor: "#42C8D3",
  fontFamily: "default",
  fontWeight: 400,
  headingSize: 40,
  bodySize: 14,
  textStyle: "normal",
  backgroundDim: 76,
  tintColor: "#07101C",
  tintOpacity: 0,
  cardOpacity: 92,
};

export const questStoreAppearanceTable = pgTable("quest_store_appearance", {
  id: integer("id").primaryKey().default(1),
  season: text("season").notNull().default("default"),
  backgroundImagePath: text("background_image_path"),
  designSettings: jsonb("design_settings")
    .$type<Partial<StoreDesignSettings>>()
    .notNull()
    .default(sql`'{}'::jsonb`),
  updatedAt: timestamp("updated_at", { withTimezone: true })
    .notNull()
    .defaultNow()
    .$onUpdate(() => new Date()),
});

export const insertQuestStoreAppearanceSchema = createInsertSchema(
  questStoreAppearanceTable,
).omit({ updatedAt: true });

export type QuestStoreAppearanceRecord =
  typeof questStoreAppearanceTable.$inferSelect;
export type InsertQuestStoreAppearance = z.infer<
  typeof insertQuestStoreAppearanceSchema
>;

import { createInsertSchema } from "drizzle-zod";
import { integer, pgTable, text, timestamp, boolean } from "drizzle-orm/pg-core";
import { z } from "zod/v4";

export const questStoreMetaTable = pgTable("quest_store_meta", {
  id: integer("id").primaryKey().default(1),
  points: integer("points").notNull().default(4800),
  updatedAt: timestamp("updated_at", { withTimezone: true })
    .notNull()
    .defaultNow()
    .$onUpdate(() => new Date()),
});

export const questCharactersTable = pgTable("quest_characters", {
  id: text("id").primaryKey(),
  name: text("name").notNull(),
  description: text("description").notNull(),
  cost: integer("cost").notNull(),
  unlocked: boolean("unlocked").notNull().default(false),
  imageUrl: text("image_url"),
  updatedAt: timestamp("updated_at", { withTimezone: true })
    .notNull()
    .defaultNow()
    .$onUpdate(() => new Date()),
});

export const questRewardsTable = pgTable("quest_rewards", {
  id: text("id").primaryKey(),
  name: text("name").notNull(),
  description: text("description").notNull(),
  cost: integer("cost").notNull(),
  imageUrl: text("image_url"),
  updatedAt: timestamp("updated_at", { withTimezone: true })
    .notNull()
    .defaultNow()
    .$onUpdate(() => new Date()),
});

export const insertQuestStoreMetaSchema = createInsertSchema(questStoreMetaTable).omit({
  updatedAt: true,
});
export const insertQuestCharacterSchema = createInsertSchema(questCharactersTable).omit({
  updatedAt: true,
});
export const insertQuestRewardSchema = createInsertSchema(questRewardsTable).omit({
  updatedAt: true,
});

export type QuestStoreMeta = typeof questStoreMetaTable.$inferSelect;
export type InsertQuestStoreMeta = z.infer<typeof insertQuestStoreMetaSchema>;
export type QuestCharacterRecord = typeof questCharactersTable.$inferSelect;
export type InsertQuestCharacter = z.infer<typeof insertQuestCharacterSchema>;
export type QuestRewardRecord = typeof questRewardsTable.$inferSelect;
export type InsertQuestReward = z.infer<typeof insertQuestRewardSchema>;

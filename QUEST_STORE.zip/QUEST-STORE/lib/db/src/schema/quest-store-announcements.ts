import { createInsertSchema } from "drizzle-zod";
import { boolean, pgTable, text, timestamp } from "drizzle-orm/pg-core";
import { z } from "zod/v4";

export const questStoreAnnouncementsTable = pgTable(
  "quest_store_announcements",
  {
    id: text("id").primaryKey(),
    title: text("title").notNull(),
    body: text("body").notNull(),
    imagePath: text("image_path"),
    imagePaths: text("image_paths").array().notNull().default([]),
    published: boolean("published").notNull().default(false),
    createdAt: timestamp("created_at", { withTimezone: true })
      .notNull()
      .defaultNow(),
    updatedAt: timestamp("updated_at", { withTimezone: true })
      .notNull()
      .defaultNow()
      .$onUpdate(() => new Date()),
  },
);

export const insertQuestStoreAnnouncementSchema = createInsertSchema(
  questStoreAnnouncementsTable,
).omit({ createdAt: true, updatedAt: true });

export type QuestStoreAnnouncementRecord =
  typeof questStoreAnnouncementsTable.$inferSelect;
export type InsertQuestStoreAnnouncement = z.infer<
  typeof insertQuestStoreAnnouncementSchema
>;

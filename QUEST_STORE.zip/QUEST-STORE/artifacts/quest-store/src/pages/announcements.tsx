import { useEffect, useMemo, useRef, useState, type FormEvent } from 'react';
import { useQueryClient } from '@tanstack/react-query';
import { Check, ImagePlus, Megaphone, Pencil, Plus, Send, Trash2, X } from 'lucide-react';
import {
  getGetQuestStoreAdminAnnouncementsQueryKey,
  getGetQuestStoreAnnouncementsQueryKey,
  useCreateQuestStoreAnnouncement,
  useDeleteQuestStoreAnnouncement,
  useGetQuestStoreAdminAnnouncements,
  useGetQuestStoreAnnouncements,
  useUpdateQuestStoreAnnouncement,
  type StoreAnnouncement,
} from '@workspace/api-client-react';
import { useUpload } from '../lib/use-upload';
import { resolveStoreImageUrl } from '../lib/store-image';

const MAX_PHOTOS = 8;
const allowedTypes = ['image/jpeg', 'image/png', 'image/webp', 'image/avif'];
const stamp = (value: string) => new Date(value).toLocaleString('ru-RU', { dateStyle: 'long', timeStyle: 'short' });
const photosOf = (item: StoreAnnouncement) => item.imagePaths?.length ? item.imagePaths : item.imagePath ? [item.imagePath] : [];

type PhotoDraft = { key: string; file?: File; preview: string; path?: string };
const makeKey = () => `${Date.now()}-${Math.random().toString(36).slice(2)}`;

function PublicAnnouncement({ item }: { item: StoreAnnouncement }) {
  const photos = photosOf(item);
  return <article className="announcement-public shop-card overflow-hidden rounded-xl" data-testid={`card-announcement-${item.id}`}>
    <div className="border-b border-cyan-200/10 px-5 py-5 sm:px-7">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <p className="section-kicker flex items-center gap-2"><Megaphone size={13} /> ОБЪЯВЛЕНИЕ КОМАНДЫ</p>
        <time className="mono text-[9px] tracking-wide text-slate-500" dateTime={item.createdAt} data-testid={`text-announcement-date-${item.id}`}>{stamp(item.createdAt)}</time>
      </div>
      <h3 className="display-font mt-3 text-2xl font-semibold leading-tight text-slate-100 sm:text-3xl" data-testid={`text-announcement-title-${item.id}`}>{item.title}</h3>
      <p className="mt-3 whitespace-pre-wrap text-sm leading-7 text-slate-300" data-testid={`text-announcement-body-${item.id}`}>{item.body}</p>
    </div>
    {photos.length > 0 && <div className={`grid gap-1.5 bg-[#080f19]/60 p-1.5 ${photos.length === 1 ? 'grid-cols-1' : 'grid-cols-2 sm:grid-cols-3'}`} data-testid={`gallery-announcement-${item.id}`}>
      {photos.map((path, index) => <a key={`${path}-${index}`} className={`relative block overflow-hidden rounded-md border border-slate-700/40 bg-slate-950/50 ${photos.length === 1 ? 'max-h-[520px]' : 'aspect-[4/3]'}`} href={resolveStoreImageUrl(path) ?? undefined} target="_blank" rel="noreferrer" aria-label={`Открыть фото ${index + 1} к объявлению`} data-testid={`link-announcement-photo-${item.id}-${index}`}>
        <img src={resolveStoreImageUrl(path) ?? undefined} alt={`Фото ${index + 1} к объявлению «${item.title}»`} className={`h-full w-full ${photos.length === 1 ? 'object-contain' : 'object-cover'}`} data-testid={`img-announcement-${item.id}-${index}`} />
      </a>)}
    </div>}
  </article>;
}

export function PublicAnnouncements() {
  const query = useGetQuestStoreAnnouncements({ query: { queryKey: getGetQuestStoreAnnouncementsQueryKey(), refetchOnWindowFocus: true, refetchInterval: 30_000 } });
  const published = useMemo(() => (query.data ?? []).filter((item) => item.published), [query.data]);
  return <section className="scroll-mt-24 py-3 sm:py-5" data-testid="section-public-announcements">
    <div className="mb-6 flex flex-col justify-between gap-3 sm:flex-row sm:items-end">
      <div><p className="section-kicker flex items-center gap-2"><Megaphone size={13} /> ГОЛОС ОБЩЕГО МИРА</p><h2 className="display-font mt-2 text-4xl font-semibold text-slate-100 sm:text-5xl">Объявления</h2><p className="mt-2 max-w-xl text-xs leading-5 text-slate-500">Новости и важные вести для всей команды — только для чтения.</p></div>
      {published.length > 0 && <span className="mono text-[9px] tracking-[.12em] text-cyan-100/50" data-testid="text-announcement-count">{published.length.toString().padStart(2, '0')} / ЗАПИСЕЙ</span>}
    </div>
    {query.isLoading && <div className="space-y-3" data-testid="status-announcements-loading"><div className="skeleton h-40 rounded-xl" /><div className="skeleton h-28 rounded-xl" /></div>}
    {query.isError && <div className="admin-panel rounded-xl p-6 text-center" data-testid="status-announcements-error"><p className="text-sm text-rose-200">Не удалось загрузить объявления.</p><button type="button" onClick={() => query.refetch()} className="button-primary mt-4 rounded-lg px-4 py-2 text-xs font-bold" data-testid="button-retry-announcements">Повторить загрузку</button></div>}
    {!query.isLoading && !query.isError && published.length === 0 && <div className="admin-panel rounded-xl border-dashed p-8 text-center" data-testid="empty-public-announcements"><p className="display-font text-xl font-semibold text-slate-300">Пока тихо</p><p className="mt-2 text-xs text-slate-500">Опубликованные вести появятся здесь.</p></div>}
    {!query.isLoading && !query.isError && published.length > 0 && <div className="space-y-4">{published.map((item) => <PublicAnnouncement key={item.id} item={item} />)}</div>}
  </section>;
}

function AnnouncementEditor({ item, onClose, onSaved }: { item?: StoreAnnouncement; onClose: () => void; onSaved: (message: string) => void }) {
  const initialPhotos = item ? photosOf(item).map((path) => ({ key: makeKey(), preview: resolveStoreImageUrl(path) ?? path, path })) : [];
  const [title, setTitle] = useState(item?.title ?? '');
  const [body, setBody] = useState(item?.body ?? '');
  const [published, setPublished] = useState(item?.published ?? false);
  const [photos, setPhotos] = useState<PhotoDraft[]>(initialPhotos);
  const [fileError, setFileError] = useState('');
  const [saved, setSaved] = useState(false);
  const upload = useUpload();
  const create = useCreateQuestStoreAnnouncement();
  const update = useUpdateQuestStoreAnnouncement();
  const client = useQueryClient();
  const photosRef = useRef(photos);
  photosRef.current = photos;
  const busy = upload.isUploading || create.isPending || update.isPending;

  useEffect(() => () => photosRef.current.forEach((photo) => { if (photo.file) URL.revokeObjectURL(photo.preview); }), []);

  const updatePhotos = (next: PhotoDraft[] | ((old: PhotoDraft[]) => PhotoDraft[])) => {
    setPhotos((old) => {
      const value = typeof next === 'function' ? next(old) : next;
      photosRef.current = value;
      return value;
    });
  };
  const chooseFiles = (files: FileList | null) => {
    if (!files?.length) return;
    const room = MAX_PHOTOS - photos.length;
    const accepted: PhotoDraft[] = [];
    let message = '';
    Array.from(files).forEach((file) => {
      if (!allowedTypes.includes(file.type)) { message = 'Поддерживаются изображения JPEG, PNG, WebP и AVIF.'; return; }
      if (file.size > 15 * 1024 * 1024) { message = 'Размер каждого изображения не должен превышать 15 МБ.'; return; }
      if (accepted.length >= room) { message = `В объявлении может быть не более ${MAX_PHOTOS} фотографий.`; return; }
      accepted.push({ key: makeKey(), file, preview: URL.createObjectURL(file) });
    });
    if (room <= 0) message = `Достигнут предел: ${MAX_PHOTOS} фотографий.`;
    updatePhotos((old) => [...old, ...accepted].slice(0, MAX_PHOTOS));
    setFileError(message);
    setSaved(false);
  };
  const removePhoto = (key: string) => {
    const target = photos.find((photo) => photo.key === key);
    if (target?.file) URL.revokeObjectURL(target.preview);
    updatePhotos((old) => old.filter((photo) => photo.key !== key));
    setFileError('');
  };
  const refreshAnnouncements = async () => {
    await Promise.all([
      client.invalidateQueries({ queryKey: getGetQuestStoreAnnouncementsQueryKey() }),
      client.invalidateQueries({ queryKey: getGetQuestStoreAdminAnnouncementsQueryKey() }),
    ]);
  };
  const submit = async (event: FormEvent) => {
    event.preventDefault();
    if (!title.trim() || !body.trim() || title.trim().length > 120 || body.trim().length > 5000) return;
    setSaved(false);
    setFileError('');
    const paths: string[] = [];
    for (const photo of photosRef.current) {
      if (photo.path) { paths.push(photo.path); continue; }
      if (!photo.file) continue;
      const result = await upload.uploadFile(photo.file);
      if (!result) {
        setFileError('Не удалось загрузить одно из фото. Черновик сохранён: уже загруженные фото повторно загружаться не будут.');
        return;
      }
      paths.push(result.objectPath);
      updatePhotos((current) => current.map((entry) => entry.key === photo.key ? { ...entry, path: result.objectPath } : entry));
    }
    const data = { title: title.trim(), body: body.trim(), imagePaths: paths, imagePath: paths[0] ?? null, published };
    try {
      if (item) await update.mutateAsync({ id: item.id, data });
      else await create.mutateAsync({ data });
      await refreshAnnouncements();
      setSaved(true);
      onSaved(item ? (published ? 'Изменения объявления сохранены.' : 'Объявление сохранено как черновик.') : (published ? 'Новое объявление опубликовано.' : 'Черновик объявления создан.'));
      onClose();
    } catch {
      // Keep file paths and previews in state so a save retry does not upload completed files again.
    }
  };

  return <form onSubmit={submit} className="admin-panel rounded-xl p-4 sm:p-5" data-testid={item ? `form-announcement-${item.id}` : 'form-announcement-create'}>
    <div className="mb-4 flex items-start justify-between gap-3">
      <div><p className="section-kicker">{item ? 'ИЗМЕНИТЬ ЗАПИСЬ' : 'НОВАЯ ЗАПИСЬ'}</p><h3 className="display-font mt-1 text-2xl font-semibold text-slate-100">{item ? 'Редактор объявления' : 'Объявление для команды'}</h3></div>
      <button type="button" onClick={onClose} className="grid h-9 w-9 shrink-0 place-items-center rounded-lg border border-slate-700 text-slate-400 hover:text-slate-100" aria-label="Закрыть редактор" data-testid="button-close-announcement-editor"><X size={16} /></button>
    </div>
    <div className="grid gap-3">
      <label className="text-[10px] font-semibold text-slate-400">Заголовок
        <input className="input-dark mt-1.5 w-full rounded-md px-3 py-3 text-sm" maxLength={120} required value={title} onChange={(event) => setTitle(event.target.value)} placeholder="Например: Сбор у северных ворот" data-testid="input-announcement-title" />
        <span className="mt-1 block text-right mono text-[9px] text-slate-600">{title.length}/120</span>
      </label>
      <label className="text-[10px] font-semibold text-slate-400">Текст объявления
        <textarea className="input-dark mt-1.5 min-h-[140px] w-full resize-y rounded-md px-3 py-3 text-sm leading-6" maxLength={5000} required value={body} onChange={(event) => setBody(event.target.value)} placeholder="Расскажите команде, что происходит…" data-testid="input-announcement-body" />
        <span className="mt-1 block text-right mono text-[9px] text-slate-600">{body.length}/5000</span>
      </label>
      <div>
        <div className="mb-2 flex items-center justify-between gap-2"><p className="text-[10px] font-semibold text-slate-400">ФОТОГРАФИИ <span className="mono text-cyan-100/60">{photos.length}/{MAX_PHOTOS}</span></p><span className="text-[9px] text-slate-600">до 15 МБ каждое</span></div>
        <label className={`inline-flex min-h-[42px] cursor-pointer items-center justify-center gap-2 rounded-lg border px-4 text-xs font-bold transition ${photos.length >= MAX_PHOTOS ? 'cursor-not-allowed border-slate-800 text-slate-600' : 'border-cyan-200/25 text-cyan-100 hover:border-cyan-200/50'}`} data-testid="label-announcement-photos">
          <ImagePlus size={14} /> Добавить фото
          <input className="sr-only" type="file" multiple accept="image/jpeg,image/png,image/webp,image/avif" disabled={photos.length >= MAX_PHOTOS || busy} onChange={(event) => { chooseFiles(event.target.files); event.target.value = ''; }} data-testid="input-announcement-photos" />
        </label>
        {photos.length > 0 && <div className="mt-3 grid grid-cols-2 gap-2 sm:grid-cols-4" data-testid="grid-announcement-photo-drafts">{photos.map((photo, index) => <div key={photo.key} className="relative aspect-[4/3] overflow-hidden rounded-lg border border-slate-700/70 bg-[#080f1b]" data-testid={`draft-announcement-photo-${index}`}>
          <img src={photo.preview} alt={`Предпросмотр фото ${index + 1}`} className="h-full w-full object-cover" />
          {photo.path && <span className="absolute bottom-1.5 left-1.5 rounded bg-[#07101c]/85 px-1.5 py-1 mono text-[8px] text-emerald-200" data-testid={`status-announcement-photo-uploaded-${index}`}>ЗАГРУЖЕНО</span>}
          <button type="button" onClick={() => removePhoto(photo.key)} aria-label={`Удалить фото ${index + 1}`} className="absolute right-1.5 top-1.5 grid h-8 w-8 place-items-center rounded-md border border-white/15 bg-[#07101c]/85 text-white hover:border-rose-200/50 hover:text-rose-100" data-testid={`button-remove-announcement-photo-${index}`}><X size={14} /></button>
        </div>)}</div>}
      </div>
      <label className="flex cursor-pointer items-center gap-3 rounded-lg border border-slate-700/70 bg-slate-950/25 px-3 py-3 text-xs text-slate-300" data-testid="label-announcement-published">
        <input type="checkbox" className="h-4 w-4 accent-cyan-300" checked={published} onChange={(event) => setPublished(event.target.checked)} data-testid="input-announcement-published" />
        <span><span className="block font-semibold text-slate-200">Опубликовать для всей команды</span><span className="mt-1 block text-[10px] text-slate-500">Черновик виден только автору.</span></span>
      </label>
      {(fileError || upload.error) && <p className="text-xs leading-5 text-rose-200" role="alert" data-testid="status-announcement-upload-error">{fileError || 'Не удалось загрузить изображение. Повторите попытку.'}</p>}
      {upload.isUploading && <div data-testid="status-announcement-uploading"><div className="mb-1 flex justify-between text-[10px] text-cyan-100"><span>Загружаем фотографию</span><span className="mono">{upload.progress}%</span></div><div className="h-1 overflow-hidden rounded bg-slate-800"><div className="h-full bg-cyan-300" style={{ width: `${upload.progress}%` }} /></div></div>}
      {create.isError || update.isError ? <p className="text-xs text-rose-200" role="alert" data-testid="status-announcement-save-error">Не удалось сохранить объявление. Черновик и уже загруженные фото сохранены для повтора.</p> : null}
      {saved && <p className="flex items-center gap-1.5 text-xs text-emerald-300" data-testid="status-announcement-saved"><Check size={13} /> Объявление сохранено.</p>}
      <div className="flex flex-col-reverse gap-2 border-t border-slate-700/50 pt-4 sm:flex-row sm:justify-end">
        <button type="button" onClick={onClose} className="min-h-[42px] rounded-lg border border-slate-700 px-4 text-xs font-semibold text-slate-300 hover:border-slate-500" data-testid="button-cancel-announcement">Отмена</button>
        <button type="submit" disabled={busy || !title.trim() || !body.trim()} className="button-primary inline-flex min-h-[42px] items-center justify-center gap-2 rounded-lg px-5 text-xs font-bold disabled:cursor-not-allowed disabled:opacity-50" data-testid="button-save-announcement"><Send size={13} />{upload.isUploading ? 'Загружаем фото' : create.isPending || update.isPending ? 'Сохраняем' : published ? 'Сохранить и опубликовать' : 'Сохранить черновик'}</button>
      </div>
    </div>
  </form>;
}

export function AdminAnnouncements() {
  const query = useGetQuestStoreAdminAnnouncements({ query: { queryKey: getGetQuestStoreAdminAnnouncementsQueryKey(), refetchOnWindowFocus: true } });
  const [editing, setEditing] = useState<StoreAnnouncement | null>(null);
  const [creating, setCreating] = useState(false);
  const [feedback, setFeedback] = useState('');
  const [operationError, setOperationError] = useState('');
  const client = useQueryClient();
  const update = useUpdateQuestStoreAnnouncement();
  const remove = useDeleteQuestStoreAnnouncement();
  const refresh = async () => Promise.all([
    client.invalidateQueries({ queryKey: getGetQuestStoreAnnouncementsQueryKey() }),
    client.invalidateQueries({ queryKey: getGetQuestStoreAdminAnnouncementsQueryKey() }),
  ]);
  const togglePublished = async (item: StoreAnnouncement) => {
    setFeedback('');
    setOperationError('');
    try {
      await update.mutateAsync({ id: item.id, data: { published: !item.published } });
      await refresh();
      setFeedback(item.published ? 'Объявление снято с публикации.' : 'Объявление опубликовано для команды.');
    } catch { setOperationError('Не удалось изменить публикацию. Повторите попытку.'); }
  };
  const deleteAnnouncement = async (item: StoreAnnouncement) => {
    if (!window.confirm(`Удалить объявление «${item.title}»? Это действие нельзя отменить.`)) return;
    setFeedback('');
    setOperationError('');
    try {
      await remove.mutateAsync({ id: item.id });
      await refresh();
      setFeedback('Объявление удалено.');
      if (editing?.id === item.id) setEditing(null);
    } catch { setOperationError('Не удалось удалить объявление. Повторите попытку.'); }
  };
  return <section className="pt-12" data-testid="section-admin-announcements">
    <div className="mb-5 flex flex-col justify-between gap-3 sm:flex-row sm:items-end">
      <div><p className="section-kicker flex items-center gap-2"><Megaphone size={13} /> СВЯЗЬ С КОМАНДОЙ</p><h2 className="display-font mt-2 text-3xl font-semibold text-slate-100">Объявления</h2><p className="mt-1 max-w-xl text-xs leading-5 text-slate-500">Публикуйте новости для всех участников или сохраняйте их приватными черновиками.</p></div>
      {!creating && !editing && <button type="button" onClick={() => { setCreating(true); setFeedback(''); }} className="button-primary inline-flex min-h-[42px] items-center justify-center gap-2 rounded-lg px-4 text-xs font-bold" data-testid="button-new-announcement"><Plus size={15} /> Новое объявление</button>}
    </div>
    {feedback && <p className="mb-3 rounded-lg border border-emerald-200/15 bg-emerald-300/[.04] px-3 py-2.5 text-xs text-emerald-200" role="status" data-testid="status-announcement-operation-success">{feedback}</p>}
    {operationError && <p className="mb-3 rounded-lg border border-rose-200/15 bg-rose-300/[.04] px-3 py-2.5 text-xs text-rose-200" role="alert" data-testid="status-announcement-operation-error">{operationError}</p>}
    {query.isLoading && <div className="space-y-3" data-testid="status-admin-announcements-loading"><div className="skeleton h-24 rounded-xl" /><div className="skeleton h-24 rounded-xl" /></div>}
    {query.isError && <div className="admin-panel rounded-xl p-5 text-xs text-rose-200" role="alert" data-testid="status-admin-announcements-error">Не удалось загрузить список объявлений. <button type="button" onClick={() => query.refetch()} className="ml-2 underline underline-offset-4" data-testid="button-retry-admin-announcements">Повторить</button></div>}
    {creating && <div className="mb-4"><AnnouncementEditor onClose={() => setCreating(false)} onSaved={setFeedback} /></div>}
    {editing && <div className="mb-4"><AnnouncementEditor key={editing.id} item={editing} onClose={() => setEditing(null)} onSaved={setFeedback} /></div>}
    {!query.isLoading && !query.isError && (query.data?.length ?? 0) === 0 && !creating && <div className="admin-panel rounded-xl border-dashed p-7 text-center" data-testid="empty-admin-announcements"><p className="display-font text-xl font-semibold text-slate-300">Доска ждёт первую весть</p><p className="mt-2 text-xs text-slate-500">Создайте объявление: его можно оставить черновиком или сразу опубликовать.</p></div>}
    {!query.isLoading && !query.isError && Boolean(query.data?.length) && <div className="space-y-3">{query.data?.map((item) => <article key={item.id} className="admin-panel rounded-xl p-4 sm:p-5" data-testid={`admin-announcement-${item.id}`}>
      <div className="flex flex-col justify-between gap-4 sm:flex-row sm:items-start">
        <div className="min-w-0"><div className="flex flex-wrap items-center gap-2"><span className={`rounded-full border px-2.5 py-1 mono text-[8px] tracking-[.1em] ${item.published ? 'border-emerald-200/20 bg-emerald-300/[.06] text-emerald-200' : 'border-amber-200/20 bg-amber-300/[.05] text-amber-100'}`} data-testid={`status-announcement-${item.id}`}>{item.published ? 'ОПУБЛИКОВАНО' : 'ЧЕРНОВИК'}</span><time className="mono text-[9px] text-slate-600" dateTime={item.updatedAt} data-testid={`text-admin-announcement-date-${item.id}`}>Обновлено {stamp(item.updatedAt)}</time></div>
          <h3 className="display-font mt-3 break-words text-2xl font-semibold text-slate-100" data-testid={`text-admin-announcement-title-${item.id}`}>{item.title}</h3><p className="mt-2 line-clamp-3 whitespace-pre-wrap text-xs leading-5 text-slate-400" data-testid={`text-admin-announcement-body-${item.id}`}>{item.body}</p>
          <div className="mt-3 flex flex-wrap gap-1.5">{photosOf(item).map((path, index) => <img key={`${path}-${index}`} src={resolveStoreImageUrl(path) ?? undefined} alt="" className="h-12 w-16 rounded border border-slate-700/70 object-cover" data-testid={`img-admin-announcement-${item.id}-${index}`} />)}{photosOf(item).length === 0 && <span className="text-[9px] text-slate-600">Без фотографий</span>}</div>
        </div>
        <div className="flex shrink-0 flex-wrap gap-2 sm:justify-end">
          <button type="button" onClick={() => { setCreating(false); setEditing(item); setFeedback(''); }} className="inline-flex min-h-[38px] items-center gap-1.5 rounded-lg border border-slate-700 px-3 text-[10px] font-semibold text-slate-300 hover:border-cyan-200/35 hover:text-cyan-100" data-testid={`button-edit-announcement-${item.id}`}><Pencil size={12} /> Изменить</button>
          <button type="button" disabled={update.isPending} onClick={() => void togglePublished(item)} className="inline-flex min-h-[38px] items-center gap-1.5 rounded-lg border border-cyan-200/20 px-3 text-[10px] font-semibold text-cyan-100 hover:border-cyan-200/45 disabled:opacity-50" data-testid={`button-toggle-announcement-${item.id}`}>{item.published ? 'Снять с публикации' : 'Опубликовать'}</button>
          <button type="button" disabled={remove.isPending} onClick={() => void deleteAnnouncement(item)} className="inline-flex min-h-[38px] items-center gap-1.5 rounded-lg border border-rose-200/15 px-3 text-[10px] font-semibold text-rose-200 hover:border-rose-200/40 disabled:opacity-50" data-testid={`button-delete-announcement-${item.id}`}><Trash2 size={12} /> Удалить</button>
        </div>
      </div>
    </article>)}</div>}
  </section>;
}

import { useEffect, useRef, useState, type FormEvent } from 'react';
import { Link } from 'wouter';
import { useAuth, useClerk, useUser } from '@clerk/react';
import { ArrowLeft, Check, CircleAlert, CloudUpload, Gem, ImagePlus, LockKeyhole, LogOut, Save, ShieldCheck, UserRound, X } from 'lucide-react';
import { useQueryClient } from '@tanstack/react-query';
import {
  getGetQuestStoreAppearanceQueryKey,
  getGetQuestStoreAdminQueryKey,
  getGetQuestStoreQueryKey,
  useGetQuestStoreAppearance,
  useGetQuestStoreAdmin,
  useUpdateQuestStoreAppearance,
  useUpdateQuestStoreBalance,
  useUpdateQuestStoreCharacter,
  useUpdateQuestStoreReward,
  type QuestCharacter,
  type StoreDesign,
  type SpecialReward,
} from '@workspace/api-client-react';
import { useUpload } from '../lib/use-upload';
import { isAppStorageObjectPath, resolveStoreImageUrl } from '../lib/store-image';
import { DEFAULT_STORE_DESIGN, storeThemeStyle } from '../lib/store-design';
import { AdminAnnouncements } from './announcements';

function AdminHeader() {
  const { signOut } = useClerk();
  const { user } = useUser();
  return <header className="topbar sticky top-0 z-30">
    <div className="mx-auto flex h-[68px] max-w-6xl items-center justify-between px-4 sm:px-7">
      <Link href="/" className="flex items-center gap-2 text-xs font-semibold text-slate-300 hover:text-cyan-100" data-testid="link-back-to-store"><ArrowLeft size={15} /> <span className="hidden sm:inline">Вернуться в магазин</span><span className="sm:hidden">Магазин</span></Link>
      <div className="display-font text-lg font-bold tracking-[.14em] text-slate-100">QUEST STORE <span className="text-cyan-300">/</span> АВТОР</div>
      <button className="flex items-center gap-2 rounded-lg border border-slate-700/80 px-2.5 py-2 text-[10px] text-slate-400 hover:border-cyan-300/30 hover:text-slate-200 sm:px-3" onClick={() => signOut({ redirectUrl: import.meta.env.BASE_URL || '/' })} data-testid="button-sign-out">
        <span className="grid h-5 w-5 place-items-center rounded-full bg-slate-700 text-[9px] text-cyan-100">{user?.firstName?.slice(0,1) || <UserRound size={11} />}</span><span className="hidden sm:inline">{user?.firstName || 'Автор'}</span><LogOut size={13} />
      </button>
    </div>
  </header>;
}

function AuthGate() {
  const { isLoaded, isSignedIn } = useAuth();
  if (!isLoaded) return <main className="quest-shell grid min-h-[100dvh] place-items-center"><div className="skeleton h-64 w-[min(90%,460px)] rounded-2xl" /></main>;
  if (!isSignedIn) return <main className="quest-shell grid min-h-[100dvh] place-items-center px-4 py-10">
    <div className="admin-panel w-full max-w-lg rounded-2xl p-7 text-center sm:p-10" data-testid="status-admin-sign-in-required">
      <div className="mx-auto grid h-14 w-14 place-items-center rounded-full border border-cyan-200/25 bg-cyan-300/[.06] text-cyan-200"><LockKeyhole size={23} /></div>
      <p className="section-kicker mt-6">ЗАКРЫТАЯ ЗОНА</p><h1 className="display-font mt-2 text-4xl font-semibold text-slate-100">Панель автора</h1>
      <p className="mx-auto mt-3 max-w-sm text-sm leading-6 text-slate-400">Войдите в аккаунт автора. Право редактировать проверяется защищённым сервером, а не настройкой в браузере.</p>
      <div className="mt-7 flex flex-col justify-center gap-3 sm:flex-row">
        <Link href="/sign-in" className="button-primary inline-flex items-center justify-center rounded-lg px-5 py-3 text-sm font-bold" data-testid="link-admin-sign-in">Войти</Link>
        <Link href="/sign-up" className="inline-flex items-center justify-center rounded-lg border border-slate-700 px-5 py-3 text-sm font-semibold text-slate-300 hover:border-slate-500" data-testid="link-admin-sign-up">Создать аккаунт</Link>
      </div>
      <Link href="/" className="mt-6 inline-block text-xs text-slate-500 hover:text-cyan-200" data-testid="link-public-shop">← К общей доске</Link>
    </div>
  </main>;
  return <AdminDashboard />;
}

function UnauthorizedState({ retry }: { retry: () => void }) {
  return <main className="quest-shell min-h-[100dvh]">
    <AdminHeader /><div className="mx-auto max-w-2xl px-4 py-16 sm:px-7">
      <div className="admin-panel rounded-2xl p-7 text-center sm:p-10" data-testid="status-admin-unauthorized">
        <div className="mx-auto grid h-14 w-14 place-items-center rounded-full border border-rose-200/20 bg-rose-300/[.05] text-rose-200"><CircleAlert size={22} /></div>
        <p className="section-kicker mt-6 text-rose-200">ДОСТУП ОТКЛОНЁН</p><h1 className="display-font mt-2 text-4xl font-semibold text-slate-100">Недостаточно прав</h1>
        <p className="mx-auto mt-3 max-w-md text-sm leading-6 text-slate-400">Сервер не подтвердил доступ автора к общей доске. Данные магазина не показаны, редактирование заблокировано.</p>
        <button onClick={retry} className="button-primary mt-7 inline-flex items-center gap-2 rounded-lg px-5 py-3 text-sm font-bold" data-testid="button-retry-admin"><ShieldCheck size={15} /> Проверить доступ снова</button>
      </div>
    </div>
  </main>;
}

function useRefreshStore() {
  const client = useQueryClient();
  return () => {
    void client.invalidateQueries({ queryKey: getGetQuestStoreQueryKey() });
    void client.invalidateQueries({ queryKey: getGetQuestStoreAdminQueryKey() });
  };
}

function BalanceEditor({ points }: { points: number }) {
  const [value, setValue] = useState(String(points));
  const [saved, setSaved] = useState(false);
  const [dirty, setDirty] = useState(false);
  useEffect(() => { if (!dirty) setValue(String(points)); }, [points, dirty]);
  const mutation = useUpdateQuestStoreBalance();
  const refresh = useRefreshStore();
  const submit = (event: FormEvent) => {
    event.preventDefault();
    const numeric = Number(value);
    if (!Number.isFinite(numeric) || numeric < 0) return;
    setSaved(false);
    mutation.mutate({ data: { points: numeric } }, { onSuccess: () => { setSaved(true); setDirty(false); refresh(); } });
  };
  return <form onSubmit={submit} className="admin-panel flex flex-col gap-4 rounded-xl p-5 sm:flex-row sm:items-end sm:justify-between sm:p-6" data-testid="form-shared-balance">
    <div><p className="section-kicker">ОБЩИЙ РЕСУРС КОМАНДЫ</p><label htmlFor="shared-points" className="display-font mt-2 block text-2xl font-semibold text-slate-100">Баланс очков</label><p className="mt-1 text-xs text-slate-500">Изменение увидят все игроки общей доски.</p></div>
    <div className="flex items-center gap-3">
      <div className="relative"><Gem size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-cyan-200" /><input id="shared-points" className="input-dark w-36 rounded-lg py-3 pl-9 pr-3 mono text-sm" type="number" min="0" step="1" value={value} onChange={(e) => { setValue(e.target.value); setDirty(true); }} data-testid="input-shared-points" /></div>
      <button disabled={mutation.isPending} className="button-primary inline-flex min-h-[44px] items-center gap-2 rounded-lg px-4 text-xs font-bold disabled:opacity-50" type="submit" data-testid="button-save-balance"><Save size={14} />{mutation.isPending ? 'Сохраняем' : 'Обновить'}</button>
    </div>
    {saved && <span className="flex items-center gap-1 text-xs text-emerald-300 sm:absolute sm:ml-auto" data-testid="status-balance-saved"><Check size={13} /> Баланс сохранён</span>}
    {mutation.isError && <p className="w-full text-xs text-rose-300" role="alert" data-testid="status-balance-error">Не удалось сохранить. Проверьте доступ и повторите попытку.</p>}
  </form>;
}

type AppearanceSeason = 'default' | 'spring' | 'summer' | 'autumn' | 'winter';
const appearanceSeasons: { value: AppearanceSeason; label: string; note: string }[] = [
  { value: 'default', label: 'Без сезона', note: 'Туманная бездна' },
  { value: 'spring', label: 'Весна', note: 'Мягкая зелень' },
  { value: 'summer', label: 'Лето', note: 'Морской свет' },
  { value: 'autumn', label: 'Осень', note: 'Тёплый янтарь' },
  { value: 'winter', label: 'Зима', note: 'Ледяная дымка' },
];

function AppearanceEditor() {
  const client = useQueryClient();
  const appearanceQuery = useGetQuestStoreAppearance({ query: { queryKey: getGetQuestStoreAppearanceQueryKey() } });
  const mutation = useUpdateQuestStoreAppearance();
  const { uploadFile, isUploading, error: uploadError, progress } = useUpload();
  const [season, setSeason] = useState<AppearanceSeason>('default');
  const [backgroundImagePath, setBackgroundImagePath] = useState<string | null>(null);
  const [design, setDesign] = useState<StoreDesign>(DEFAULT_STORE_DESIGN);
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);
  const [uploadedPath, setUploadedPath] = useState<string | null>(null);
  const [dirty, setDirty] = useState(false);
  const [saved, setSaved] = useState(false);
  const [fileError, setFileError] = useState('');
  const savedSettings = useRef<{ season: AppearanceSeason; backgroundImagePath: string | null; design: StoreDesign } | null>(null);
  const initialized = useRef(false);

  useEffect(() => {
    if (appearanceQuery.data && !initialized.current) {
      initialized.current = true;
      setSeason(appearanceQuery.data.season);
      setBackgroundImagePath(appearanceQuery.data.backgroundImagePath);
      setDesign(appearanceQuery.data.design);
      savedSettings.current = { season: appearanceQuery.data.season, backgroundImagePath: appearanceQuery.data.backgroundImagePath, design: appearanceQuery.data.design };
    }
  }, [appearanceQuery.data]);

  useEffect(() => () => {
    if (previewUrl) URL.revokeObjectURL(previewUrl);
  }, [previewUrl]);

  const imageUrl = previewUrl ?? (backgroundImagePath
    ? resolveStoreImageUrl(backgroundImagePath)
    : null);
  const colorFields: { key: keyof Pick<StoreDesign, 'primaryColor' | 'backgroundColor' | 'bodyTextColor' | 'headingColor' | 'numberColor' | 'buttonColor' | 'buttonTextColor' | 'cardColor' | 'borderColor' | 'accentColor'>; label: string }[] = [
    { key: 'primaryColor', label: 'Основной цвет' }, { key: 'backgroundColor', label: 'Цвет фона' },
    { key: 'bodyTextColor', label: 'Основной текст' }, { key: 'headingColor', label: 'Заголовки' },
    { key: 'numberColor', label: 'Очки и цены' }, { key: 'buttonColor', label: 'Кнопки' },
    { key: 'buttonTextColor', label: 'Текст кнопок' }, { key: 'cardColor', label: 'Карточки и панели' },
    { key: 'borderColor', label: 'Границы' }, { key: 'accentColor', label: 'Акцент' },
  ];
  const changeDesign = (update: Partial<StoreDesign>) => {
    setDesign((current) => ({ ...current, ...update }));
    setDirty(true);
    setSaved(false);
    mutation.reset();
  };
  const restoreSaved = () => {
    const savedState = savedSettings.current;
    if (!savedState) return;
    setSeason(savedState.season);
    setBackgroundImagePath(savedState.backgroundImagePath);
    setDesign(savedState.design);
    setSelectedFile(null);
    setUploadedPath(null);
    if (previewUrl) URL.revokeObjectURL(previewUrl);
    setPreviewUrl(null);
    setFileError('');
    setDirty(false);
    setSaved(false);
    mutation.reset();
  };

  const chooseFile = (file: File | undefined) => {
    if (!file) return;
    const allowedTypes = ['image/jpeg', 'image/png', 'image/webp', 'image/avif'];
    if (!allowedTypes.includes(file.type)) {
      setFileError('Поддерживаются изображения JPEG, PNG, WebP и AVIF.');
      return;
    }
    if (file.size > 15 * 1024 * 1024) {
      setFileError('Размер изображения не должен превышать 15 МБ.');
      return;
    }
    setFileError('');
    setSaved(false);
    setDirty(true);
    setUploadedPath(null);
    setPreviewUrl(URL.createObjectURL(file));
    setSelectedFile(file);
    mutation.reset();
  };

  const removeBackground = () => {
    setBackgroundImagePath(null);
    setSelectedFile(null);
    setUploadedPath(null);
    setPreviewUrl(null);
    setFileError('');
    setDirty(true);
    setSaved(false);
    mutation.reset();
  };

  const submit = async (event: FormEvent) => {
    event.preventDefault();
    if (!appearanceQuery.data) {
      setFileError('Сначала загрузите сохранённое оформление, затем можно вносить изменения.');
      return;
    }
    setSaved(false);
    setFileError('');
    let pathToSave = uploadedPath ?? backgroundImagePath;
    if (selectedFile && !uploadedPath) {
      const uploadResult = await uploadFile(selectedFile);
      if (!uploadResult) {
        setFileError('Не удалось загрузить изображение. Проверьте доступ автора и повторите попытку.');
        return;
      }
      pathToSave = uploadResult.objectPath;
      setUploadedPath(uploadResult.objectPath);
      setBackgroundImagePath(uploadResult.objectPath);
    }
    try {
      const result = await mutation.mutateAsync({ data: { season, backgroundImagePath: pathToSave, design } });
      setSeason(result.season);
      setBackgroundImagePath(result.backgroundImagePath);
      setDesign(result.design);
      savedSettings.current = { season: result.season, backgroundImagePath: result.backgroundImagePath, design: result.design };
      setSelectedFile(null);
      setUploadedPath(null);
      setPreviewUrl(null);
      setDirty(false);
      setSaved(true);
      client.setQueryData(getGetQuestStoreAppearanceQueryKey(), result);
      await client.invalidateQueries({ queryKey: getGetQuestStoreAppearanceQueryKey() });
    } catch {
      // Keep the uploaded object path and preview so the author can retry without uploading again.
    }
  };

  return <section className="admin-panel rounded-xl p-5 sm:p-6" data-testid="section-store-appearance">
    <div className="mb-5 flex flex-col justify-between gap-3 sm:flex-row sm:items-end">
      <div><p className="section-kicker flex items-center gap-2"><ImagePlus size={13} /> ОБЛИК ОБЩЕГО МИРА</p><h2 className="display-font mt-2 text-2xl font-semibold text-slate-100 sm:text-3xl">Дизайн и оформление</h2><p className="mt-1 max-w-xl text-xs leading-5 text-slate-500">Настройте атмосферу общей лавки и проверьте её на живом образце.</p></div>
      <span className="mono text-[9px] tracking-[.12em] text-cyan-100/50">ОБЩАЯ НАСТРОЙКА</span>
    </div>
    {appearanceQuery.isLoading && <div className="skeleton mb-5 h-24 rounded-lg" data-testid="status-appearance-loading" />}
    {appearanceQuery.isError && <div className="mb-4 flex flex-col gap-2 rounded-lg border border-rose-300/20 bg-rose-300/[.04] p-3 text-xs text-rose-200 sm:flex-row sm:items-center sm:justify-between" role="alert" data-testid="status-appearance-load-error"><span>Не удалось загрузить текущее оформление. Сохранение отключено, чтобы не перезаписать текущий фон и сезон.</span><button type="button" onClick={() => void appearanceQuery.refetch()} className="min-h-[38px] rounded-md border border-rose-200/25 px-3 font-semibold hover:border-rose-200/50" data-testid="button-retry-appearance">Повторить загрузку</button></div>}
    <form onSubmit={submit} className="grid gap-5" data-testid="form-store-appearance">
      <div>
        <p className="mb-2 text-[10px] font-semibold tracking-wide text-slate-400">СЕЗОННОЕ НАСТРОЕНИЕ</p>
        <div className="grid grid-cols-2 gap-2 sm:grid-cols-3" role="group" aria-label="Выбор сезона" data-testid="group-appearance-seasons">
          {appearanceSeasons.map((option) => <button key={option.value} type="button" aria-pressed={season === option.value} onClick={() => { setSeason(option.value); setDirty(true); setSaved(false); mutation.reset(); }} className={`rounded-lg border px-3 py-3 text-left transition ${season === option.value ? 'border-cyan-200/55 bg-cyan-300/[.09] text-cyan-100 shadow-[inset_0_0_20px_rgba(63,211,222,.06)]' : 'border-slate-700/70 bg-slate-950/25 text-slate-300 hover:border-slate-500'}`} data-testid={`button-season-${option.value}`}>
            <span className="block text-xs font-bold">{option.label}</span><span className="mt-1 block text-[9px] text-slate-500">{option.note}</span>
          </button>)}
        </div>
        <p className="mt-3 text-[10px] leading-5 text-slate-600">Сезон добавляет лёгкий цветовой отблеск, не меняя контраст текста.</p>
      </div>
      <div className="min-w-0">
        <p className="mb-2 text-[10px] font-semibold tracking-wide text-slate-400">ОБЩИЙ ФОНОВЫЙ ОБРАЗ</p>
        <div className="relative flex min-h-[176px] items-center justify-center overflow-hidden rounded-lg border border-slate-700/70 bg-[#080f1b]">
          {imageUrl ? <img src={imageUrl} alt="Предпросмотр фона общей доски" className="absolute inset-0 h-full w-full object-cover opacity-75" data-testid="img-appearance-preview" /> : <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_50%_110%,rgba(51,203,218,.2),transparent_55%),linear-gradient(135deg,#101d2d,#080f1a)]" />}
          <div className="absolute inset-0 bg-gradient-to-t from-[#07101c]/95 via-[#07101c]/35 to-[#07101c]/45" />
          <div className="relative z-[1] px-5 py-7 text-center"><CloudUpload className="mx-auto text-cyan-200" size={24} /><p className="display-font mt-2 text-xl font-semibold text-slate-100">Образ для общей доски</p><p className="mt-1 text-[10px] text-slate-300/80">{selectedFile ? selectedFile.name : imageUrl ? 'Текущий фон опубликован' : 'Пока используется туманный фон'}</p></div>
          {imageUrl && <button type="button" onClick={removeBackground} className="absolute right-2 top-2 z-[2] inline-flex min-h-9 items-center gap-1.5 rounded-md border border-rose-100/20 bg-[#07101c]/85 px-2.5 text-[10px] font-semibold text-rose-100 hover:border-rose-100/45" data-testid="button-remove-background"><X size={13} /> Убрать фон</button>}
        </div>
        <div className="mt-3 flex flex-col gap-2 sm:flex-row sm:items-center">
          <label className="button-primary inline-flex min-h-[42px] cursor-pointer items-center justify-center gap-2 rounded-lg px-4 text-xs font-bold" data-testid="label-choose-background">
            <ImagePlus size={14} /> {imageUrl ? 'Выбрать другое изображение' : 'Выбрать изображение'}
            <input className="sr-only" type="file" accept="image/jpeg,image/png,image/webp,image/avif" disabled={isUploading || mutation.isPending} onChange={(event) => { chooseFile(event.target.files?.[0]); event.target.value = ''; }} data-testid="input-background-image" />
          </label>
          <span className="text-[9px] leading-4 text-slate-600">JPEG, PNG, WebP или AVIF · до 15 МБ</span>
        </div>
      </div>
      <div className="grid gap-5 border-t border-slate-700/50 pt-5 lg:grid-cols-[1fr_.9fr]">
        <div>
          <div className="mb-3"><p className="section-kicker">ЦВЕТОВАЯ СИСТЕМА</p><h3 className="display-font mt-1 text-xl font-semibold text-slate-100">Палитра мира</h3></div>
          <div className="grid gap-2 sm:grid-cols-2" data-testid="group-design-colors">
            {colorFields.map(({ key, label }) => <label key={key} className="design-control">
              <span>{label}</span><div className="design-color"><input type="color" aria-label={label} value={design[key]} onChange={(event) => changeDesign({ [key]: event.target.value } as Partial<StoreDesign>)} data-testid={`input-design-${key}`} /><span className="mono text-[10px] text-slate-300">{design[key].toUpperCase()}</span></div>
            </label>)}
          </div>
          <div className="mt-5 grid gap-3 sm:grid-cols-2">
            <label className="design-control"><span>Семейство шрифта</span><select className="input-dark min-h-[42px] rounded-md px-3 text-xs" value={design.fontFamily} onChange={(event) => changeDesign({ fontFamily: event.target.value as StoreDesign['fontFamily'] })} data-testid="select-design-font-family"><option value="default">Фирменный системный</option><option value="system">Системный</option><option value="serif">Книжный</option><option value="mono">Моноширинный</option><option value="rounded">Округлый</option></select></label>
            <label className="design-control"><span>Насыщенность: {design.fontWeight}</span><input className="design-range" type="range" min="300" max="800" step="100" value={design.fontWeight} onChange={(event) => changeDesign({ fontWeight: Number(event.target.value) })} data-testid="range-design-font-weight" /></label>
            <label className="design-control"><span>Размер заголовка: {design.headingSize} px</span><input className="design-range" type="range" min="24" max="64" step="1" value={design.headingSize} onChange={(event) => changeDesign({ headingSize: Number(event.target.value) })} data-testid="range-design-heading-size" /></label>
            <label className="design-control"><span>Размер основного текста: {design.bodySize} px</span><input className="design-range" type="range" min="12" max="20" step="1" value={design.bodySize} onChange={(event) => changeDesign({ bodySize: Number(event.target.value) })} data-testid="range-design-body-size" /></label>
            <div className="design-control sm:col-span-2"><span>Манера текста</span><div className="grid grid-cols-3 gap-2" role="group" aria-label="Манера текста">
              {([{ value: 'normal', label: 'Обычная' }, { value: 'italic', label: 'Курсив' }, { value: 'wide', label: 'Разрядка' }] as const).map((option) => <button type="button" key={option.value} aria-pressed={design.textStyle === option.value} onClick={() => changeDesign({ textStyle: option.value })} className={`min-h-[40px] rounded-md border px-2 text-[10px] font-semibold ${design.textStyle === option.value ? 'border-cyan-200/50 bg-cyan-300/10 text-cyan-100' : 'border-slate-700 text-slate-400'}`} data-testid={`button-design-text-style-${option.value}`}>{option.label}</button>)}
            </div></div>
          </div>
        </div>
        <div className="space-y-4">
          <div><p className="section-kicker">СВЕТ И ГЛУБИНА</p><h3 className="display-font mt-1 text-xl font-semibold text-slate-100">Настроение фона</h3></div>
          <label className="design-control"><span>Затемнение изображения: {design.backgroundDim}%</span><input className="design-range" type="range" min="0" max="90" value={design.backgroundDim} onChange={(event) => changeDesign({ backgroundDim: Number(event.target.value) })} data-testid="range-design-background-dim" /></label>
          <label className="design-control"><span>Цветовой оттенок</span><div className="design-color"><input type="color" aria-label="Цветовой оттенок" value={design.tintColor} onChange={(event) => changeDesign({ tintColor: event.target.value })} data-testid="input-design-tint-color" /><span className="mono text-[10px] text-slate-300">{design.tintColor.toUpperCase()}</span></div></label>
          <label className="design-control"><span>Интенсивность оттенка: {design.tintOpacity}%</span><input className="design-range" type="range" min="0" max="80" value={design.tintOpacity} onChange={(event) => changeDesign({ tintOpacity: Number(event.target.value) })} data-testid="range-design-tint-opacity" /></label>
          <label className="design-control"><span>Непрозрачность карточек: {design.cardOpacity}%</span><input className="design-range" type="range" min="45" max="100" value={design.cardOpacity} onChange={(event) => changeDesign({ cardOpacity: Number(event.target.value) })} data-testid="range-design-card-opacity" /></label>
          <div className="design-preview min-h-[220px] p-4" style={storeThemeStyle({ season, backgroundImagePath, design, updatedAt: null }, design)} data-testid="preview-store-design">
            <div className="design-preview-backdrop" style={imageUrl ? { backgroundImage: `url("${imageUrl}")` } : { background: 'radial-gradient(ellipse at 50% 100%,rgba(66,200,211,.2),transparent 55%),linear-gradient(135deg,#101d2d,#080f1a)' }} /><div className="design-preview-dim" /><div className="design-preview-tint" /><div className="design-preview-season" data-season={season} />
            <p className="relative text-[9px] font-bold tracking-[.18em]" style={{ color: design.accentColor }}>ПРЕДПРОСМОТР · {appearanceSeasons.find((entry) => entry.value === season)?.label.toUpperCase()}</p>
            <div className="design-preview-card relative mt-3 rounded-lg p-4"><h4 className="display-font" style={{ color: design.headingColor, fontSize: `${Math.min(design.headingSize, 34)}px`, fontWeight: design.fontWeight }}>Лавка команды</h4><p className="mt-2 leading-5" style={{ color: design.bodyTextColor, fontSize: `${design.bodySize}px` }}>Общие открытия и награды ждут своих героев.</p><div className="mt-4 flex items-center justify-between gap-2"><span className="mono text-sm" style={{ color: design.numberColor }}>1 240 очков</span><span className="rounded-md px-3 py-2 text-[10px] font-bold" style={{ background: design.buttonColor, color: design.buttonTextColor }}>Открыть</span></div></div>
          </div>
          <p className="text-[9px] text-slate-600" data-testid="status-design-live-preview">Предпросмотр учитывает несохранённые изменения.</p>
        </div>
      </div>
      {(fileError || uploadError) && <p className="text-xs text-rose-300 lg:col-span-2" role="alert" data-testid="status-appearance-upload-error">{fileError || uploadError?.message}</p>}
      {isUploading && <div className="lg:col-span-2" data-testid="status-appearance-uploading"><div className="mb-1 flex justify-between text-[10px] text-cyan-100"><span>Загружаем изображение</span><span className="mono">{progress}%</span></div><div className="h-1.5 overflow-hidden rounded-full bg-slate-800"><div className="h-full bg-cyan-300 transition-[width]" style={{ width: `${progress}%` }} /></div></div>}
      <div className="flex flex-col gap-3 border-t border-slate-700/50 pt-4 sm:flex-row sm:items-center sm:justify-between lg:col-span-2">
        <div className="min-h-5">
          {saved && <p className="flex items-center gap-1.5 text-xs text-emerald-300" data-testid="status-appearance-saved"><Check size={13} /> Оформление опубликовано для всей команды</p>}
          {mutation.isError && <p className="text-xs text-rose-300" role="alert" data-testid="status-appearance-save-error">Не удалось сохранить. Загруженное изображение сохранено для повторной попытки.</p>}
          {!saved && !mutation.isError && <p className="text-[10px] text-slate-600">{appearanceQuery.data?.updatedAt ? `Последнее обновление: ${new Date(appearanceQuery.data.updatedAt).toLocaleString('ru-RU', { dateStyle: 'medium', timeStyle: 'short' })}` : 'Изменения станут общими после сохранения.'}</p>}
        </div>
        <div className="flex flex-col gap-2 sm:flex-row">
          <button type="button" onClick={restoreSaved} disabled={!dirty || isUploading || mutation.isPending} className="min-h-[44px] rounded-lg border border-slate-700 px-4 text-xs font-semibold text-slate-300 disabled:opacity-40" data-testid="button-reset-appearance-draft">Сбросить изменения</button>
          <button type="button" onClick={() => changeDesign(DEFAULT_STORE_DESIGN)} className="min-h-[44px] rounded-lg border border-cyan-200/20 px-4 text-xs font-semibold text-cyan-100 hover:border-cyan-200/45" data-testid="button-restore-default-design">Вернуть стандартный стиль</button>
          <button className="button-primary inline-flex min-h-[44px] items-center justify-center gap-2 rounded-lg px-5 text-xs font-bold disabled:cursor-not-allowed disabled:opacity-50" type="submit" disabled={!appearanceQuery.data || isUploading || mutation.isPending} data-testid="button-save-appearance"><Save size={14} />{isUploading ? 'Загружаем' : mutation.isPending ? 'Сохраняем' : 'Сохранить оформление'}</button>
        </div>
      </div>
    </form>
  </section>;
}

type EditFields = { name: string; description: string; cost: string; imageUrl: string; unlocked?: boolean };

function useStoreImageDraft() {
  const { uploadFile, isUploading, progress } = useUpload();
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);
  const [uploadedPath, setUploadedPath] = useState<string | null>(null);
  const [removeRequested, setRemoveRequested] = useState(false);
  const [error, setError] = useState('');

  useEffect(() => {
    if (!previewUrl) return;
    return () => URL.revokeObjectURL(previewUrl);
  }, [previewUrl]);

  const chooseFile = (file?: File) => {
    if (!file) return;
    const allowedTypes = ['image/jpeg', 'image/png', 'image/webp', 'image/avif'];
    if (!allowedTypes.includes(file.type)) {
      setError('Поддерживаются изображения JPEG, PNG, WebP и AVIF.');
      return;
    }
    if (file.size > 15 * 1024 * 1024) {
      setError('Размер изображения не должен превышать 15 МБ.');
      return;
    }
    setError('');
    setSelectedFile(file);
    setPreviewUrl(URL.createObjectURL(file));
    setUploadedPath(null);
    setRemoveRequested(false);
  };

  const remove = () => {
    setSelectedFile(null);
    setPreviewUrl(null);
    setUploadedPath(null);
    setRemoveRequested(true);
    setError('');
  };

  const clearManualDraft = () => {
    setSelectedFile(null);
    setPreviewUrl(null);
    setUploadedPath(null);
    setRemoveRequested(false);
    setError('');
  };

  const resolveImage = async (currentValue: string) => {
    if (removeRequested) return { success: true as const, imageUrl: null };
    if (uploadedPath) return { success: true as const, imageUrl: uploadedPath };
    if (!selectedFile) {
      return { success: true as const, imageUrl: currentValue.trim() || null };
    }

    const result = await uploadFile(selectedFile);
    if (!result) {
      setError('Не удалось загрузить изображение. Проверьте доступ автора и повторите попытку.');
      return { success: false as const, imageUrl: null };
    }
    setUploadedPath(result.objectPath);
    return { success: true as const, imageUrl: result.objectPath };
  };

  const clearAfterSave = () => {
    setSelectedFile(null);
    setPreviewUrl(null);
    setUploadedPath(null);
    setRemoveRequested(false);
    setError('');
  };

  return {
    selectedFile,
    previewUrl,
    uploadedPath,
    removeRequested,
    isUploading,
    progress,
    error,
    chooseFile,
    remove,
    clearManualDraft,
    resolveImage,
    clearAfterSave,
  };
}

function ImageAssetField({
  itemId,
  kind,
  imageUrl,
  draft,
  onUrlChange,
}: {
  itemId: string;
  kind: 'character' | 'reward';
  imageUrl: string;
  draft: ReturnType<typeof useStoreImageDraft>;
  onUrlChange: (value: string) => void;
}) {
  const imageValue = draft.uploadedPath ?? imageUrl;
  const previewSrc = draft.previewUrl ?? (
    draft.removeRequested ? null : resolveStoreImageUrl(imageValue)
  );
  const urlInputValue = draft.removeRequested || draft.previewUrl || isAppStorageObjectPath(imageValue)
    ? ''
    : imageUrl;
  const [imageFailed, setImageFailed] = useState(false);
  useEffect(() => setImageFailed(false), [previewSrc]);

  return <div className="sm:col-span-2" data-testid={`section-${kind}-image-${itemId}`}>
    <p className="mb-2 text-[10px] font-semibold text-slate-400">ИЗОБРАЖЕНИЕ</p>
    <div className="grid gap-3 sm:grid-cols-[minmax(0,180px)_1fr]">
      <div className="relative grid min-h-[132px] place-items-center overflow-hidden rounded-lg border border-slate-700/70 bg-[#080f1b]">
        {previewSrc && !imageFailed
          ? <img src={previewSrc} alt={`Предпросмотр: ${kind === 'character' ? 'персонаж' : 'награда'}`} className="absolute inset-0 h-full w-full object-cover" onError={() => setImageFailed(true)} data-testid={`img-${kind}-preview-${itemId}`} />
          : <div className="px-3 text-center text-[10px] leading-5 text-slate-600" data-testid={`placeholder-${kind}-preview-${itemId}`}>{previewSrc ? 'Не удалось загрузить изображение' : 'Фото пока не добавлено'}</div>}
        {draft.previewUrl && <span className="absolute bottom-2 left-2 rounded bg-[#07101c]/85 px-2 py-1 mono text-[8px] text-cyan-100">ПРЕДПРОСМОТР</span>}
      </div>
      <div className="flex min-w-0 flex-col gap-2">
        <label className="button-primary inline-flex min-h-[42px] cursor-pointer items-center justify-center gap-2 rounded-lg px-4 text-xs font-bold">
          <ImagePlus size={14} /> Выбрать фото с телефона
          <input
            className="sr-only"
            type="file"
            accept="image/jpeg,image/png,image/webp,image/avif"
            disabled={draft.isUploading}
            onChange={(event) => {
              draft.chooseFile(event.target.files?.[0]);
              event.target.value = '';
            }}
            data-testid={`input-${kind}-image-file-${itemId}`}
          />
        </label>
        <span className="text-[9px] leading-4 text-slate-600">JPEG, PNG, WebP или AVIF · до 15 МБ. Изображение загрузится в App Storage при сохранении.</span>
        {(imageUrl || draft.previewUrl || draft.uploadedPath) && <button type="button" onClick={draft.remove} className="inline-flex min-h-[38px] items-center justify-center gap-2 rounded-lg border border-rose-200/20 px-3 text-[10px] font-semibold text-rose-100 hover:border-rose-200/45" data-testid={`button-remove-${kind}-image-${itemId}`}><X size={13} /> Удалить изображение</button>}
        <label className="text-[10px] font-semibold text-slate-400">Или использовать внешнюю ссылку
          <input
            className="input-dark mt-1.5 w-full rounded-md px-3 py-2.5 text-xs"
            type="url"
            placeholder="https://…"
            value={urlInputValue}
            onChange={(event) => {
              draft.clearManualDraft();
              onUrlChange(event.target.value);
            }}
            data-testid={`input-${kind}-image-url-${itemId}`}
          />
        </label>
      </div>
    </div>
    {draft.error && <p className="mt-2 text-[10px] text-rose-300" role="alert" data-testid={`status-${kind}-image-error-${itemId}`}>{draft.error}</p>}
    {draft.isUploading && <div className="mt-2" data-testid={`status-${kind}-image-uploading-${itemId}`}><div className="mb-1 flex justify-between text-[9px] text-cyan-100"><span>Загружаем изображение</span><span className="mono">{draft.progress}%</span></div><div className="h-1 overflow-hidden rounded bg-slate-800"><div className="h-full bg-cyan-300" style={{ width: `${draft.progress}%` }} /></div></div>}
  </div>;
}

function CharacterEditor({ item }: { item: QuestCharacter }) {
  const [fields, setFields] = useState<EditFields>({ name: item.name, description: item.description, cost: String(item.cost), imageUrl: item.imageUrl ?? '', unlocked: item.unlocked });
  const [saved, setSaved] = useState(false);
  const [dirty, setDirty] = useState(false);
  const mutation = useUpdateQuestStoreCharacter();
  const refresh = useRefreshStore();
  const imageDraft = useStoreImageDraft();
  useEffect(() => { if (!dirty) setFields({ name: item.name, description: item.description, cost: String(item.cost), imageUrl: item.imageUrl ?? '', unlocked: item.unlocked }); }, [item, dirty]);
  const change = (key: keyof EditFields, value: string | boolean) => { setDirty(true); setFields((old) => ({ ...old, [key]: value })); };
  const submit = async (event: FormEvent) => {
    event.preventDefault();
    const cost = Number(fields.cost);
    if (!fields.name.trim() || !fields.description.trim() || !Number.isFinite(cost) || cost < 0) return;
    setSaved(false);
    const image = await imageDraft.resolveImage(fields.imageUrl);
    if (!image.success) return;
    mutation.mutate({ id: item.id, data: { name: fields.name.trim(), description: fields.description.trim(), cost, unlocked: fields.unlocked, imageUrl: image.imageUrl } }, { onSuccess: () => { imageDraft.clearAfterSave(); setFields((old) => ({ ...old, imageUrl: image.imageUrl ?? '' })); setSaved(true); setDirty(false); refresh(); } });
  };
  return <form onSubmit={submit} className="admin-panel overflow-hidden rounded-xl" data-testid={`form-character-${item.id}`}>
    <div className="flex items-center justify-between border-b border-slate-700/50 px-4 py-3"><div><p className="section-kicker text-[8px]">ПЕРСОНАЖ</p><h3 className="display-font mt-1 text-xl font-semibold text-slate-100">{item.name}</h3></div>
      <label className="flex cursor-pointer items-center gap-2 rounded-full border border-slate-700 px-3 py-2 text-[10px] text-slate-300"><input type="checkbox" checked={Boolean(fields.unlocked)} onChange={(e) => change('unlocked', e.target.checked)} className="accent-cyan-300" data-testid={`input-character-unlocked-${item.id}`} /><span>{fields.unlocked ? 'Открыт' : 'Закрыт'}</span></label>
    </div>
    <div className="grid gap-3 p-4 sm:grid-cols-2">
      <label className="text-[10px] font-semibold text-slate-400">Название<input className="input-dark mt-1.5 w-full rounded-md px-3 py-2.5 text-xs" maxLength={80} value={fields.name} onChange={(e) => change('name', e.target.value)} data-testid={`input-character-name-${item.id}`} /></label>
      <label className="text-[10px] font-semibold text-slate-400">Стоимость очков<input className="input-dark mt-1.5 w-full rounded-md px-3 py-2.5 mono text-xs" type="number" min="0" step="1" value={fields.cost} onChange={(e) => change('cost', e.target.value)} data-testid={`input-character-cost-${item.id}`} /></label>
      <label className="text-[10px] font-semibold text-slate-400 sm:col-span-2">Описание<textarea className="input-dark mt-1.5 min-h-[72px] w-full resize-y rounded-md px-3 py-2.5 text-xs leading-5" maxLength={240} value={fields.description} onChange={(e) => change('description', e.target.value)} data-testid={`input-character-description-${item.id}`} /></label>
      <ImageAssetField itemId={item.id} kind="character" imageUrl={fields.imageUrl} draft={imageDraft} onUrlChange={(value) => change('imageUrl', value)} />
      <div className="flex items-center justify-between sm:col-span-2"><span className="text-[9px] text-slate-600">Изображение увидят все участники магазина.</span><button className="button-primary inline-flex items-center gap-2 rounded-md px-3.5 py-2.5 text-[10px] font-bold disabled:opacity-50" type="submit" disabled={mutation.isPending || imageDraft.isUploading} data-testid={`button-save-character-${item.id}`}><Save size={13} />{imageDraft.isUploading ? 'Загружаем' : mutation.isPending ? 'Сохраняем' : 'Сохранить'}</button></div>
      {saved && <p className="flex items-center gap-1 text-[10px] text-emerald-300" data-testid={`status-character-saved-${item.id}`}><Check size={12} /> Изменения опубликованы</p>}
      {mutation.isError && <p role="alert" className="text-[10px] text-rose-300" data-testid={`status-character-error-${item.id}`}>Не удалось сохранить — доступ не подтверждён или сервер недоступен.</p>}
    </div>
  </form>;
}

function RewardEditor({ item }: { item: SpecialReward }) {
  const [fields, setFields] = useState<EditFields>({ name: item.name, description: item.description, cost: String(item.cost), imageUrl: item.imageUrl ?? '' });
  const [saved, setSaved] = useState(false);
  const [dirty, setDirty] = useState(false);
  const mutation = useUpdateQuestStoreReward();
  const refresh = useRefreshStore();
  const imageDraft = useStoreImageDraft();
  useEffect(() => { if (!dirty) setFields({ name: item.name, description: item.description, cost: String(item.cost), imageUrl: item.imageUrl ?? '' }); }, [item, dirty]);
  const change = (key: keyof EditFields, value: string) => { setDirty(true); setFields((old) => ({ ...old, [key]: value })); };
  const submit = async (event: FormEvent) => {
    event.preventDefault();
    const cost = Number(fields.cost);
    if (!fields.name.trim() || !fields.description.trim() || !Number.isFinite(cost) || cost < 0) return;
    setSaved(false);
    const image = await imageDraft.resolveImage(fields.imageUrl);
    if (!image.success) return;
    mutation.mutate({ id: item.id, data: { name: fields.name.trim(), description: fields.description.trim(), cost, imageUrl: image.imageUrl } }, { onSuccess: () => { imageDraft.clearAfterSave(); setFields((old) => ({ ...old, imageUrl: image.imageUrl ?? '' })); setSaved(true); setDirty(false); refresh(); } });
  };
  return <form onSubmit={submit} className="admin-panel overflow-hidden rounded-xl" data-testid={`form-reward-${item.id}`}>
    <div className="border-b border-slate-700/50 px-4 py-3"><p className="section-kicker text-[8px]">ОСОБАЯ НАГРАДА</p><h3 className="display-font mt-1 text-xl font-semibold text-slate-100">{item.name}</h3></div>
    <div className="grid gap-3 p-4 sm:grid-cols-2">
      <label className="text-[10px] font-semibold text-slate-400">Название<input className="input-dark mt-1.5 w-full rounded-md px-3 py-2.5 text-xs" maxLength={80} value={fields.name} onChange={(e) => change('name', e.target.value)} data-testid={`input-reward-name-${item.id}`} /></label>
      <label className="text-[10px] font-semibold text-slate-400">Стоимость очков<input className="input-dark mt-1.5 w-full rounded-md px-3 py-2.5 mono text-xs" type="number" min="0" step="1" value={fields.cost} onChange={(e) => change('cost', e.target.value)} data-testid={`input-reward-cost-${item.id}`} /></label>
      <label className="text-[10px] font-semibold text-slate-400 sm:col-span-2">Описание<textarea className="input-dark mt-1.5 min-h-[72px] w-full resize-y rounded-md px-3 py-2.5 text-xs leading-5" maxLength={240} value={fields.description} onChange={(e) => change('description', e.target.value)} data-testid={`input-reward-description-${item.id}`} /></label>
      <ImageAssetField itemId={item.id} kind="reward" imageUrl={fields.imageUrl} draft={imageDraft} onUrlChange={(value) => change('imageUrl', value)} />
      <div className="flex items-center justify-between sm:col-span-2"><span className="text-[9px] text-slate-600">Изображение увидят все участники магазина.</span><button className="button-primary inline-flex items-center gap-2 rounded-md px-3.5 py-2.5 text-[10px] font-bold disabled:opacity-50" type="submit" disabled={mutation.isPending || imageDraft.isUploading} data-testid={`button-save-reward-${item.id}`}><Save size={13} />{imageDraft.isUploading ? 'Загружаем' : mutation.isPending ? 'Сохраняем' : 'Сохранить'}</button></div>
      {saved && <p className="flex items-center gap-1 text-[10px] text-emerald-300" data-testid={`status-reward-saved-${item.id}`}><Check size={12} /> Изменения опубликованы</p>}
      {mutation.isError && <p role="alert" className="text-[10px] text-rose-300" data-testid={`status-reward-error-${item.id}`}>Не удалось сохранить — доступ не подтверждён или сервер недоступен.</p>}
    </div>
  </form>;
}

function AdminDashboard() {
  const query = useGetQuestStoreAdmin({ query: { queryKey: getGetQuestStoreAdminQueryKey(), enabled: true, refetchOnWindowFocus: true, refetchInterval: 30_000 } });
  const appearanceQuery = useGetQuestStoreAppearance({ query: { queryKey: getGetQuestStoreAppearanceQueryKey() } });
  const [activeTab, setActiveTab] = useState<'manage' | 'design'>('manage');
  if (query.isLoading) return <main className="quest-shell min-h-[100dvh]"><AdminHeader /><div className="mx-auto max-w-6xl px-4 py-8 sm:px-7"><div className="skeleton h-36 rounded-xl" /><div className="mt-8 grid gap-4 md:grid-cols-2">{[1,2,3,4].map((n) => <div key={n} className="skeleton h-80 rounded-xl" />)}</div></div></main>;
  if (query.isError || !query.data) return <UnauthorizedState retry={() => query.refetch()} />;
  const snapshot = query.data;
  const imageUrl = appearanceQuery.data?.backgroundImagePath ? resolveStoreImageUrl(appearanceQuery.data.backgroundImagePath) : null;
  return <main className="quest-shell min-h-[100dvh]" data-themed="true" data-season={appearanceQuery.data?.season ?? 'default'} style={storeThemeStyle(appearanceQuery.data)}>
    <div className="store-world-backdrop" aria-hidden="true" style={imageUrl ? { backgroundImage: `url("${imageUrl}")` } : undefined} /><div className="store-image-dim" aria-hidden="true" /><div className="season-wash" aria-hidden="true" /><div className="store-tint-overlay" aria-hidden="true" />
    <div className="mist mist-one" /><AdminHeader />
    <div className="mx-auto max-w-6xl px-4 pb-16 pt-8 sm:px-7 sm:pt-11">
      <div className="mb-8 flex flex-col justify-between gap-4 border-b border-slate-800/80 pb-7 sm:flex-row sm:items-end">
        <div><p className="section-kicker flex items-center gap-2"><ShieldCheck size={13} /> ПРОВЕРЕННАЯ СЕССИЯ АВТОРА</p><h1 className="display-font mt-3 text-4xl font-semibold text-slate-100 sm:text-5xl">Управление доской</h1><p className="mt-2 max-w-xl text-sm leading-6 text-slate-400">Правки публикуются в общей лавке и становятся видны всей команде.</p></div>
        <span className="mono flex items-center gap-2 text-[9px] tracking-[.1em] text-emerald-300"><span className="h-1.5 w-1.5 rounded-full bg-emerald-400" /> ЗАЩИЩЁННЫЙ ДОСТУП</span>
      </div>
      <div className="mb-6 flex gap-2 overflow-x-auto border-b border-slate-800/80 pb-3" role="tablist" aria-label="Разделы панели автора" data-testid="tabs-admin">
        <button type="button" role="tab" aria-selected={activeTab === 'manage'} onClick={() => setActiveTab('manage')} className={`min-h-[42px] shrink-0 rounded-lg border px-4 text-xs font-bold ${activeTab === 'manage' ? 'border-cyan-200/45 bg-cyan-300/[.08] text-cyan-100' : 'border-transparent text-slate-400 hover:border-slate-700'}`} data-testid="tab-admin-manage">Управление</button>
        <button type="button" role="tab" aria-selected={activeTab === 'design'} onClick={() => setActiveTab('design')} className={`min-h-[42px] shrink-0 rounded-lg border px-4 text-xs font-bold ${activeTab === 'design' ? 'border-cyan-200/45 bg-cyan-300/[.08] text-cyan-100' : 'border-transparent text-slate-400 hover:border-slate-700'}`} data-testid="tab-admin-design">Дизайн и оформление</button>
      </div>
      {activeTab === 'design' ? <AppearanceEditor /> : <>
        <BalanceEditor points={snapshot.points} />
        <AdminAnnouncements />
        <section className="pt-12" data-testid="section-admin-characters"><div className="mb-5 flex items-end justify-between"><div><p className="section-kicker">КОЛЛЕКЦИЯ КОМАНДЫ</p><h2 className="display-font mt-2 text-3xl font-semibold text-slate-100">Персонажи</h2></div><span className="mono text-[9px] text-slate-600">{snapshot.characters.length} ОБЪЕКТОВ</span></div>
          {snapshot.characters.length ? <div className="grid gap-4 lg:grid-cols-2">{snapshot.characters.map((item) => <CharacterEditor key={item.id} item={item} />)}</div> : <div className="admin-panel rounded-xl p-7 text-sm text-slate-500" data-testid="empty-admin-characters">Нет персонажей для редактирования.</div>}
        </section>
        <section className="pt-12" data-testid="section-admin-rewards"><div className="mb-5 flex items-end justify-between"><div><p className="section-kicker">ОСОБЫЙ ФОНД</p><h2 className="display-font mt-2 text-3xl font-semibold text-slate-100">Награды</h2></div><span className="mono text-[9px] text-slate-600">{snapshot.rewards.length} ОБЪЕКТОВ</span></div>
          {snapshot.rewards.length ? <div className="grid gap-4 lg:grid-cols-2">{snapshot.rewards.map((item) => <RewardEditor key={item.id} item={item} />)}</div> : <div className="admin-panel rounded-xl p-7 text-sm text-slate-500" data-testid="empty-admin-rewards">Нет особых наград для редактирования.</div>}
        </section>
      </>}
    </div>
  </main>;
}

export default function AdminPage() {
  return <AuthGate />;
}

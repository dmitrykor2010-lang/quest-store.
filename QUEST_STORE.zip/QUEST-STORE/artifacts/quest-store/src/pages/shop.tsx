import { useEffect, useState, type ReactNode } from 'react';
import { Link } from 'wouter';
import { ArrowDown, ArrowUpRight, Gem, LockKeyhole, Radio, RefreshCw, ShieldCheck, Sparkles, Users } from 'lucide-react';
import { getGetQuestStoreAppearanceQueryKey, getGetQuestStoreQueryKey, useGetQuestStore, useGetQuestStoreAppearance, type QuestCharacter, type SpecialReward, type StoreAppearance } from '@workspace/api-client-react';
import { resolveStoreImageUrl } from '../lib/store-image';
import { storeThemeStyle } from '../lib/store-design';
import { PublicAnnouncements } from './announcements';

function Shell({ children, appearance }: { children: ReactNode; appearance?: StoreAppearance }) {
  const imagePath = appearance?.backgroundImagePath;
  const imageUrl = imagePath ? (imagePath.startsWith('/api/storage') ? imagePath : `/api/storage${imagePath}`) : null;
  const season = appearance?.season ?? 'default';
  return (
    <main className="quest-shell" data-themed="true" data-season={season} style={storeThemeStyle(appearance)} data-testid="store-themed-shell">
      <div className="store-world-backdrop" aria-hidden="true" style={imageUrl ? { backgroundImage: `url("${imageUrl}")` } : undefined} data-testid="store-shared-background" />
      <div className="store-image-dim" aria-hidden="true" /><div className="store-tint-overlay" aria-hidden="true" />
      <div className="season-wash" aria-hidden="true" />
      <div className="mist mist-one" /><div className="mist mist-two" />
      <div id="announcements" className="mx-auto max-w-6xl px-4 sm:px-7"><PublicAnnouncements /></div>
      <header className="topbar sticky top-0 z-30">
        <div className="mx-auto flex h-[72px] max-w-6xl items-center justify-between px-4 sm:px-7">
          <Link href="/" className="flex items-center gap-3 text-inherit no-underline" data-testid="link-home">
            <span className="brand-mark"><Gem size={18} strokeWidth={1.7} /></span>
            <span><span className="display-font block text-[21px] font-bold leading-none tracking-[.11em]">QUEST STORE</span><span className="mono mt-1 block text-[8px] tracking-[.14em] text-slate-500">Общий магазин команды</span></span>
          </Link>
          <nav className="flex items-center gap-3 sm:gap-6">
            <a href="#heroes" className="hidden text-xs text-slate-400 transition hover:text-cyan-200 sm:block" data-testid="link-catalog">Персонажи</a>
            <a href="#rewards" className="hidden text-xs text-slate-400 transition hover:text-cyan-200 sm:block" data-testid="link-rewards">Награды</a>
            <a href="#announcements" className="hidden text-xs text-slate-400 transition hover:text-cyan-200 sm:block" data-testid="link-announcements">Объявления</a>
            <Link href="/admin" className="group flex items-center gap-2 rounded-full border border-slate-700/80 px-3 py-2 text-[11px] font-semibold text-slate-300 transition hover:border-cyan-300/40 hover:text-cyan-100" data-testid="link-admin">
              <ShieldCheck size={14} className="text-cyan-300" /> <span className="hidden sm:inline">Для автора</span><ArrowUpRight size={12} />
            </Link>
          </nav>
        </div>
      </header>
      {children}
      <footer className="mx-auto mt-20 flex max-w-6xl flex-col gap-3 border-t border-slate-800/70 px-4 py-7 text-[10px] text-slate-600 sm:flex-row sm:items-center sm:justify-between sm:px-7">
        <span className="mono tracking-[.16em]">QUEST STORE <span className="text-slate-700">/</span> ОБЩИЙ МИР — ОБЩИЙ ПРОГРЕСС</span>
        <span>Только просмотр · Баланс и открытия общие для всей команды</span>
      </footer>
    </main>
  );
}

function Artwork({ src, label, kind }: { src: string | null; label: string; kind: 'character' | 'reward' }) {
  const [failed, setFailed] = useState(false);
  useEffect(() => setFailed(false), [src]);
  const imageSrc = resolveStoreImageUrl(src);
  return src && !failed
    ? <img className="h-full w-full object-cover" src={imageSrc ?? undefined} alt={label} onError={() => setFailed(true)} data-testid={`img-art-${kind}-${label}`} />
    : <div className="art-placeholder relative grid h-full w-full place-items-center overflow-hidden" aria-label={`Иллюстрация ${label} пока не добавлена`} data-testid={`placeholder-art-${kind}-${label}`}>
        <div className="relative z-[1] flex flex-col items-center text-cyan-100/50">
          {kind === 'character' ? <Sparkles size={48} strokeWidth={1} className="opacity-50" /> : <Gem size={45} strokeWidth={1} className="opacity-50" />}
          <span className="mono mt-1 text-[8px] tracking-[.3em]">{src ? 'ИЗОБРАЖЕНИЕ НЕДОСТУПНО' : 'ОБРАЗ НЕ ДОБАВЛЕН'}</span>
        </div>
      </div>;
}

function LoadingPage({ appearance }: { appearance?: StoreAppearance }) {
  return <Shell appearance={appearance}><div className="mx-auto max-w-6xl px-4 py-10 sm:px-7"><div className="skeleton h-64 rounded-2xl" /><div className="mt-12 grid grid-cols-2 gap-4 md:grid-cols-3">{[1,2,3].map((n) => <div key={n} className="skeleton h-72 rounded-xl" />)}</div></div></Shell>;
}

function ErrorPanel({ retry }: { retry: () => void }) {
  return <div className="mx-auto my-16 max-w-xl rounded-2xl border border-rose-300/15 bg-slate-900/70 p-8 text-center" data-testid="status-shop-error">
    <p className="section-kicker text-rose-200">СВЯЗЬ С ХРАНИЛИЩЕМ ПОТЕРЯНА</p><h2 className="display-font mt-4 text-3xl text-slate-100">Общий мир не отвечает</h2>
    <p className="mt-2 text-sm leading-6 text-slate-400">Не удалось загрузить состояние магазина. Попробуйте обновить соединение.</p>
    <button onClick={retry} className="button-primary mt-6 inline-flex items-center gap-2 rounded-lg px-5 py-3 text-sm font-bold" data-testid="button-retry-shop"><RefreshCw size={15} /> Повторить</button>
  </div>;
}

function CharacterCard({ item }: { item: QuestCharacter }) {
  return <article className={`shop-card overflow-hidden rounded-xl ${item.unlocked ? 'card-unlocked' : ''}`} data-testid={`card-character-${item.id}`}>
    <div className="relative h-[205px] overflow-hidden sm:h-[230px]"><Artwork src={item.imageUrl} label={item.name} kind="character" />
      <div className="absolute left-3 top-3 rounded-full border border-slate-500/30 bg-[#08101b]/85 px-2.5 py-1 mono text-[7px] tracking-[.1em] text-slate-300">{item.unlocked ? 'РАЗБЛОКИРОВАНО' : 'ЗАБЛОКИРОВАНО'}</div>
      {item.unlocked && <div className="absolute right-3 top-3 grid h-7 w-7 place-items-center rounded-full border border-cyan-200/25 bg-cyan-300/15 text-cyan-200"><Sparkles size={13} /></div>}
    </div>
    <div className="p-4 sm:p-5">
      <div className="flex items-start justify-between gap-2"><h3 className="display-font text-[23px] font-semibold leading-none text-slate-100">{item.name}</h3><span className="mono mt-1 flex shrink-0 items-center gap-1.5 text-xs text-cyan-200"><Gem size={13} />{item.cost}</span></div>
      <p className="mt-3 min-h-[48px] text-xs leading-5 text-slate-400">{item.description}</p>
      <div className="mt-4 flex items-center gap-2 border-t border-slate-700/50 pt-3 text-[10px] tracking-wide text-slate-500">
        {item.unlocked ? <><Sparkles size={12} className="text-cyan-300" /> Уже в общей коллекции</> : <><LockKeyhole size={12} /> Открытие доступно автору</>}
      </div>
    </div>
  </article>;
}

function RewardCard({ item }: { item: SpecialReward }) {
  return <article className="shop-card flex min-h-[138px] overflow-hidden rounded-xl" data-testid={`card-reward-${item.id}`}>
    <div className="relative w-[112px] shrink-0 sm:w-[142px]"><Artwork src={item.imageUrl} label={item.name} kind="reward" /><span className="absolute left-2 top-2 rounded-sm border border-amber-200/20 bg-[#11121a]/75 px-2 py-1 mono text-[7px] tracking-[.12em] text-amber-100/80">ОСОБАЯ</span></div>
    <div className="flex min-w-0 flex-1 flex-col justify-between p-4 sm:p-5"><div><h3 className="display-font text-[21px] font-semibold leading-tight text-slate-100">{item.name}</h3><p className="mt-2 text-xs leading-5 text-slate-400">{item.description}</p></div>
      <div className="mt-3 flex items-center justify-between"><span className="mono flex items-center gap-1.5 text-xs text-amber-100"><Gem size={13} className="text-cyan-200" />{item.cost} <span className="text-[9px] text-slate-500">ОЧКОВ</span></span><span className="text-[9px] text-slate-600">только автор изменяет</span></div>
    </div>
  </article>;
}

export default function ShopPage() {
  const query = useGetQuestStore({ query: { queryKey: getGetQuestStoreQueryKey(), refetchInterval: 30_000, refetchOnWindowFocus: true } });
  const appearanceQuery = useGetQuestStoreAppearance({ query: { queryKey: getGetQuestStoreAppearanceQueryKey(), refetchOnWindowFocus: true } });
  const snapshot = query.data;
  if (query.isLoading) return <LoadingPage appearance={appearanceQuery.data} />;
  if (query.isError || !snapshot) return <Shell appearance={appearanceQuery.data}><ErrorPanel retry={() => query.refetch()} /></Shell>;
  return <Shell appearance={appearanceQuery.data}>
    <div className="mx-auto max-w-6xl px-4 pb-2 pt-7 sm:px-7 sm:pt-10">
      <section className="hero-panel relative overflow-hidden rounded-2xl px-5 py-7 sm:px-10 sm:py-9" data-testid="section-store-intro">
        <div className="relative z-[1] grid gap-8 md:grid-cols-[1fr_auto] md:items-end">
          <div className="max-w-2xl">
            <div className="section-kicker flex items-center gap-2"><Radio size={13} className="animate-pulse" /> ОБЩИЙ МАГАЗИН КОМАНДЫ</div>
            <h1 className="display-font mt-4 text-[clamp(2.8rem,8vw,5.6rem)] font-bold leading-[.85] text-slate-100">НАГРАДЫ<br /><span className="text-cyan-200">ЗА ПОДВИГИ</span></h1>
            <p className="mt-5 max-w-lg text-sm leading-6 text-slate-400 sm:text-base">Здесь каждый видит один и тот же прогресс. Выполняйте квесты вместе — очки и открытия общие для всей команды.</p>
            <a href="#heroes" className="mt-6 inline-flex items-center gap-2 text-xs font-bold tracking-wide text-cyan-100 transition hover:text-white" data-testid="link-explore-catalog">Исследовать каталог <ArrowDown size={14} /></a>
          </div>
          <div className="balance-plate relative z-[1] rounded-xl px-5 py-4 md:min-w-[228px]" data-testid="panel-team-balance">
            <div className="flex items-center gap-2 text-[10px] font-bold tracking-[.16em] text-slate-400"><Users size={14} className="text-cyan-300" /> ОБЩИЙ БАЛАНС</div>
            <div className="display-font mt-2 flex items-baseline gap-2 text-5xl font-bold leading-none text-slate-50"><span data-testid="text-shared-points">{snapshot.points.toLocaleString('ru-RU')}</span><span className="text-lg font-semibold text-cyan-200">ОЧКОВ</span></div>
            <div className="mono mt-3 border-t border-cyan-200/10 pt-3 text-[8px] tracking-[.12em] text-slate-500">ОДИН ПРОГРЕСС НА ВСЕХ</div>
          </div>
        </div>
      </section>
      <div className="mt-4 flex items-center justify-between text-[10px] text-slate-600"><span className="flex items-center gap-1.5"><span className="h-1.5 w-1.5 rounded-full bg-emerald-400" /> синхронизация включена</span><span data-testid="text-updated-at">Обновлено {new Date(snapshot.updatedAt).toLocaleString('ru-RU', { dateStyle: 'medium', timeStyle: 'short' })}</span></div>

      <section id="heroes" className="scroll-mt-24 pt-14" data-testid="section-character-catalog">
        <div className="mb-6 flex items-end justify-between"><div><p className="section-kicker">ОТКРЫВАЕМЫЕ СПУТНИКИ</p><h2 className="display-font mt-2 text-4xl font-semibold text-slate-100 sm:text-5xl">Персонажи</h2></div><span className="mono hidden text-[9px] tracking-[.14em] text-slate-600 sm:block">{snapshot.characters.length.toString().padStart(2,'0')} / КАТАЛОГ</span></div>
        {snapshot.characters.length ? <div className="grid grid-cols-2 gap-3 sm:gap-5 md:grid-cols-3">{snapshot.characters.map((item) => <CharacterCard key={item.id} item={item} />)}</div> : <div className="admin-panel rounded-xl p-8 text-center text-sm text-slate-500" data-testid="empty-character-catalog">Каталог персонажей пока пуст</div>}
      </section>

      <section id="rewards" className="scroll-mt-24 pt-16" data-testid="section-special-rewards">
        <div className="mb-6"><p className="section-kicker">РЕДКИЕ СОКРОВИЩА</p><h2 className="display-font mt-2 text-4xl font-semibold text-slate-100 sm:text-5xl">Особые награды</h2><p className="mt-2 max-w-xl text-xs leading-5 text-slate-500">Особые возможности и знаки признания. Содержимое доски видит вся команда.</p></div>
        {snapshot.rewards.length ? <div className="grid gap-3 md:grid-cols-2">{snapshot.rewards.map((item) => <RewardCard key={item.id} item={item} />)}</div> : <div className="admin-panel rounded-xl p-8 text-center text-sm text-slate-500" data-testid="empty-reward-catalog">Особых наград пока нет</div>}
      </section>
      <section className="mt-16 flex flex-col gap-4 rounded-xl border border-cyan-200/10 bg-cyan-300/[.035] p-5 sm:flex-row sm:items-center sm:justify-between sm:px-7">
        <div className="flex items-center gap-4"><div className="grid h-10 w-10 shrink-0 place-items-center rounded-full border border-cyan-200/20 text-cyan-200"><Users size={17} /></div><div><p className="text-sm font-semibold text-slate-200">Общее дело — общий результат</p><p className="mt-1 text-xs text-slate-500">Эта доска показывает одну и ту же картину каждому игроку.</p></div></div>
        <span className="mono pl-14 text-[9px] tracking-[.12em] text-cyan-100/50 sm:pl-0">ТОЛЬКО ПРОСМОТР</span>
      </section>
    </div>
  </Shell>;
}

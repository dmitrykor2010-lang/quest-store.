export function isAppStorageObjectPath(value: string) {
  return value.startsWith('/objects/uploads/') ||
    value.startsWith('/api/storage/objects/uploads/');
}

export function resolveStoreImageUrl(value: string | null | undefined) {
  if (!value) return null;
  if (value.startsWith('/objects/')) return `/api/storage${value}`;
  if (value.startsWith('/api/storage/objects/')) return value;
  return value;
}

import type { CSSProperties } from 'react';
import type { StoreAppearance, StoreDesign } from '@workspace/api-client-react';

export const DEFAULT_STORE_DESIGN: StoreDesign = {
  primaryColor: '#53D9E3',
  backgroundColor: '#080D17',
  bodyTextColor: '#94A3B8',
  headingColor: '#F1F5F9',
  numberColor: '#67E8F9',
  buttonColor: '#53D9E3',
  buttonTextColor: '#07121B',
  cardColor: '#0F1927',
  borderColor: '#365366',
  accentColor: '#42C8D3',
  fontFamily: 'default',
  fontWeight: 400,
  headingSize: 40,
  bodySize: 14,
  textStyle: 'normal',
  backgroundDim: 76,
  tintColor: '#07101C',
  tintOpacity: 0,
  cardOpacity: 92,
};

export function storeThemeStyle(appearance?: StoreAppearance | null, designOverride?: StoreDesign): CSSProperties {
  const design = designOverride ?? appearance?.design ?? DEFAULT_STORE_DESIGN;
  const fontStacks = {
    default: 'var(--app-font-sans)',
    system: "system-ui, -apple-system, 'Segoe UI', sans-serif",
    serif: "Georgia, 'Times New Roman', serif",
    mono: "'SFMono-Regular', Consolas, 'Liberation Mono', monospace",
    rounded: "'Trebuchet MS', 'Arial Rounded MT Bold', sans-serif",
  } as const;
  const displayFont = design.fontFamily === 'default'
    ? 'var(--app-font-serif)'
    : fontStacks[design.fontFamily];
  const wideText = design.textStyle === 'wide';
  return {
    '--store-primary': design.primaryColor,
    '--store-background': design.backgroundColor,
    '--store-body': design.bodyTextColor,
    '--store-heading': design.headingColor,
    '--store-number': design.numberColor,
    '--store-button': design.buttonColor,
    '--store-button-text': design.buttonTextColor,
    '--store-card': design.cardColor,
    '--store-border': design.borderColor,
    '--store-accent': design.accentColor,
    '--store-font': fontStacks[design.fontFamily],
    '--store-display-font': displayFont,
    '--store-weight': design.fontWeight,
    '--store-heading-size': `${design.headingSize}px`,
    '--store-body-size': `${design.bodySize}px`,
    '--store-text-style': wideText ? '0.035em' : 'normal',
    '--store-display-letter-spacing': wideText ? '0.09em' : design.fontFamily === 'default' ? '.045em' : 'normal',
    '--store-font-style': design.textStyle === 'italic' ? 'italic' : 'normal',
    '--store-background-dim': design.backgroundDim / 100,
    '--store-tint': design.tintColor,
    '--store-tint-opacity': design.tintOpacity / 100,
    '--store-card-opacity': `${design.cardOpacity}%`,
  } as CSSProperties;
}

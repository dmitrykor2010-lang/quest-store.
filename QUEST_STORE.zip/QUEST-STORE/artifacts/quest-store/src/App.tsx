import { useEffect, useRef, type ReactNode } from 'react';
import { QueryClient, QueryClientProvider, useQueryClient } from '@tanstack/react-query';
import { ClerkProvider, SignIn, SignUp, useClerk } from '@clerk/react';
import { publishableKeyFromHost } from '@clerk/react/internal';
import { shadcn } from '@clerk/themes';
import { Route, Switch, useLocation, Router as WouterRouter } from 'wouter';
import { ErrorBoundary } from '@/components/error-boundary';
import { Toaster } from '@/components/ui/toaster';
import { TooltipProvider } from '@/components/ui/tooltip';
import ShopPage from '@/pages/shop';
import AdminPage from '@/pages/admin';
import NotFound from '@/pages/not-found';

const queryClient = new QueryClient({
  defaultOptions: { queries: { staleTime: 15_000, refetchOnWindowFocus: true, retry: 1 } },
});
const basePath = import.meta.env.BASE_URL.replace(/\/$/, '');
const clerkPubKey = publishableKeyFromHost(window.location.hostname, import.meta.env.VITE_CLERK_PUBLISHABLE_KEY);
const clerkProxyUrl = import.meta.env.VITE_CLERK_PROXY_URL;

function stripBase(path: string) {
  return basePath && path.startsWith(basePath) ? path.slice(basePath.length) || '/' : path;
}

const clerkAppearance = {
  theme: shadcn,
  cssLayerName: 'clerk',
  options: {
    logoPlacement: 'inside' as const,
    logoLinkUrl: basePath || '/',
    logoImageUrl: `${window.location.origin}${basePath}/logo.svg`,
  },
  variables: {
    colorPrimary: '#53d9e3',
    colorForeground: '#e4f1f3',
    colorMutedForeground: '#91a8b5',
    colorDanger: '#ed7770',
    colorBackground: '#0f1927',
    colorInput: '#080f19',
    colorInputForeground: '#e4f1f3',
    colorNeutral: '#294052',
    fontFamily: 'Manrope, sans-serif',
    borderRadius: '0.8rem',
  },
  elements: {
    rootBox: 'w-full flex justify-center',
    cardBox: 'bg-[#0f1927] rounded-2xl w-[440px] max-w-full overflow-hidden border border-[#294052]',
    card: '!shadow-none !border-0 !bg-transparent !rounded-none',
    footer: '!shadow-none !border-0 !bg-transparent !rounded-none',
    headerTitle: 'text-[#e4f1f3] font-semibold',
    headerSubtitle: 'text-[#91a8b5]',
    socialButtonsBlockButtonText: 'text-[#d8e9ec]',
    formFieldLabel: 'text-[#b7cbd1]',
    footerActionLink: 'text-[#65dce5]',
    footerActionText: 'text-[#91a8b5]',
    dividerText: 'text-[#91a8b5]',
    identityPreviewEditButton: 'text-[#65dce5]',
    formFieldSuccessText: 'text-[#7ce0bf]',
    alertText: 'text-[#e4f1f3]',
    logoBox: 'rounded-lg',
    logoImage: 'rounded-lg',
    socialButtonsBlockButton: 'border border-[#294052] bg-[#121f2e] hover:bg-[#1a2d3d]',
    formButtonPrimary: 'bg-[#53d9e3] text-[#07121b] hover:bg-[#8aebef]',
    formFieldInput: 'bg-[#080f19] text-[#e4f1f3] border-[#294052]',
    footerAction: 'text-[#91a8b5]',
    dividerLine: 'bg-[#294052]',
    alert: 'border-[#294052] bg-[#142132]',
    otpCodeFieldInput: 'bg-[#080f19] text-[#e4f1f3] border-[#294052]',
    formFieldRow: 'text-[#b7cbd1]',
    main: 'text-[#e4f1f3]',
  },
};

function RoutedErrorBoundary({ children }: { children: ReactNode }) {
  const [location] = useLocation();
  return <ErrorBoundary resetKey={location}>{children}</ErrorBoundary>;
}

function SignInPage() {
  return <div className="auth-stage"><p className="section-kicker mb-5">ВОЗВРАЩЕНИЕ В МИР</p><SignIn routing="path" path={`${basePath}/sign-in`} signUpUrl={`${basePath}/sign-up`} /></div>;
}

function SignUpPage() {
  return <div className="auth-stage"><p className="section-kicker mb-5">СОЗДАТЬ ПРОФИЛЬ</p><SignUp routing="path" path={`${basePath}/sign-up`} signInUrl={`${basePath}/sign-in`} /></div>;
}

function ClerkQueryClientCacheInvalidator() {
  const { addListener } = useClerk();
  const client = useQueryClient();
  const prevUserIdRef = useRef<string | null | undefined>(undefined);
  useEffect(() => {
    const unsubscribe = addListener(({ user }) => {
      const userId = user?.id ?? null;
      if (prevUserIdRef.current !== undefined && prevUserIdRef.current !== userId) client.clear();
      prevUserIdRef.current = userId;
    });
    return unsubscribe;
  }, [addListener, client]);
  return null;
}

function Routes() {
  const [, setLocation] = useLocation();
  return (
    <ClerkProvider
      publishableKey={clerkPubKey}
      proxyUrl={clerkProxyUrl}
      appearance={clerkAppearance}
      signInUrl={`${basePath}/sign-in`}
      signUpUrl={`${basePath}/sign-up`}
      localization={{
        signIn: { start: { title: 'С возвращением', subtitle: 'Войдите, чтобы открыть панель автора' } },
        signUp: { start: { title: 'Вступить в команду', subtitle: 'Создайте профиль для автора магазина' } },
      }}
      routerPush={(to) => setLocation(stripBase(to))}
      routerReplace={(to) => setLocation(stripBase(to), { replace: true })}
    >
      <QueryClientProvider client={queryClient}>
        <TooltipProvider>
          <ClerkQueryClientCacheInvalidator />
          <RoutedErrorBoundary>
            <Switch>
              <Route path="/" component={ShopPage} />
              <Route path="/admin" component={AdminPage} />
              <Route path="/sign-in/*?" component={SignInPage} />
              <Route path="/sign-up/*?" component={SignUpPage} />
              <Route component={NotFound} />
            </Switch>
          </RoutedErrorBoundary>
          <Toaster />
        </TooltipProvider>
      </QueryClientProvider>
    </ClerkProvider>
  );
}

function App() {
  if (!clerkPubKey) throw new Error('Missing VITE_CLERK_PUBLISHABLE_KEY in .env file');
  return <WouterRouter base={basePath}><Routes /></WouterRouter>;
}

export default App;

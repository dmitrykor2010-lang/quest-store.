import { getAuth } from "@clerk/express";
import {
  GetQuestStoreAppearanceResponse,
  UpdateQuestStoreAppearanceBody,
  UpdateQuestStoreAppearanceResponse,
} from "@workspace/api-zod";
import {
  db,
  DEFAULT_STORE_DESIGN_SETTINGS,
  questStoreAppearanceTable,
} from "@workspace/db";
import { eq } from "drizzle-orm";
import { Router, type IRouter } from "express";
import { ObjectStorageService } from "../lib/objectStorage";
import { requireAuthor, requireSameOrigin } from "./quest-store";

const router: IRouter = Router();
const objectStorage = new ObjectStorageService();

async function getAppearance() {
  const [row] = await db
    .select()
    .from(questStoreAppearanceTable)
    .where(eq(questStoreAppearanceTable.id, 1))
    .limit(1);

  return {
    season: row?.season ?? "default",
    backgroundImagePath: row?.backgroundImagePath ?? null,
    design: {
      ...DEFAULT_STORE_DESIGN_SETTINGS,
      ...row?.designSettings,
    },
    updatedAt: row?.updatedAt.toISOString() ?? null,
  };
}

router.get("/quest-store/appearance", async (_req, res): Promise<void> => {
  res.json(GetQuestStoreAppearanceResponse.parse(await getAppearance()));
});

router.patch(
  "/quest-store/admin/appearance",
  requireSameOrigin,
  requireAuthor,
  async (req, res): Promise<void> => {
    const parsed = UpdateQuestStoreAppearanceBody.safeParse(req.body);
    if (!parsed.success) {
      res.status(400).json({ error: parsed.error.message });
      return;
    }

    const { userId } = getAuth(req);
    if (!userId) {
      res.status(401).json({ error: "Необходимо войти в аккаунт автора." });
      return;
    }

    if (parsed.data.backgroundImagePath) {
      try {
        await objectStorage.trySetObjectEntityAclPolicy(
          parsed.data.backgroundImagePath,
          { owner: userId, visibility: "public" },
        );
      } catch (error) {
        req.log.warn({ err: error }, "Unable to use uploaded store background");
        res.status(400).json({
          error: "Изображение не найдено в постоянном хранилище.",
        });
        return;
      }
    }

    const [current] = await db
      .select({ designSettings: questStoreAppearanceTable.designSettings })
      .from(questStoreAppearanceTable)
      .where(eq(questStoreAppearanceTable.id, 1))
      .limit(1);
    const design = {
      ...DEFAULT_STORE_DESIGN_SETTINGS,
      ...current?.designSettings,
      ...parsed.data.design,
    };

    await db
      .insert(questStoreAppearanceTable)
      .values({
        id: 1,
        season: parsed.data.season,
        backgroundImagePath: parsed.data.backgroundImagePath,
        designSettings: design,
        updatedAt: new Date(),
      })
      .onConflictDoUpdate({
        target: questStoreAppearanceTable.id,
        set: {
          season: parsed.data.season,
          backgroundImagePath: parsed.data.backgroundImagePath,
          designSettings: design,
          updatedAt: new Date(),
        },
      });

    res.json(
      UpdateQuestStoreAppearanceResponse.parse(await getAppearance()),
    );
  },
);

export default router;

import { Router, type IRouter } from "express";
import healthRouter from "./health";
import questStoreRouter from "./quest-store";
import questStoreAppearanceRouter from "./quest-store-appearance";
import questStoreAnnouncementsRouter from "./quest-store-announcements";
import storageRouter from "./storage";

const router: IRouter = Router();

router.use(healthRouter);
router.use(questStoreRouter);
router.use(questStoreAppearanceRouter);
router.use(questStoreAnnouncementsRouter);
router.use(storageRouter);

export default router;

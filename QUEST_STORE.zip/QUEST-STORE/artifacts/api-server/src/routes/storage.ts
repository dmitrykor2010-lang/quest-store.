import {
  RequestUploadUrlBody,
  RequestUploadUrlResponse,
} from "@workspace/api-zod";
import {
  db,
  questCharactersTable,
  questStoreAnnouncementsTable,
  questStoreAppearanceTable,
  questRewardsTable,
} from "@workspace/db";
import { and, arrayContains, eq, or } from "drizzle-orm";
import { Router, type IRouter, type RequestHandler } from "express";
import { Readable } from "node:stream";
import { ObjectNotFoundError, ObjectStorageService } from "../lib/objectStorage";
import { requireAuthor, requireSameOrigin } from "./quest-store";

const router: IRouter = Router();
const objectStorage = new ObjectStorageService();
const objectPathPattern =
  /^\/objects\/uploads\/[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;

router.post(
  "/storage/uploads/request-url",
  requireSameOrigin,
  requireAuthor,
  async (req, res): Promise<void> => {
    const parsed = RequestUploadUrlBody.safeParse(req.body);
    if (!parsed.success) {
      res.status(400).json({ error: parsed.error.message });
      return;
    }

    try {
      const uploadURL = await objectStorage.getObjectEntityUploadURL();
      const objectPath = objectStorage.normalizeObjectEntityPath(uploadURL);
      res.json(
        RequestUploadUrlResponse.parse({
          uploadURL,
          objectPath,
          metadata: parsed.data,
        }),
      );
    } catch (error) {
      req.log.error({ err: error }, "Unable to create store image upload URL");
      res.status(500).json({ error: "Не удалось подготовить загрузку изображения." });
    }
  },
);

const allowPublicStoreImagesOrRequireAuthor: RequestHandler = async (
  req,
  res,
  next,
): Promise<void> => {
  const raw = req.params.path;
  const wildcardPath = Array.isArray(raw) ? raw.join("/") : raw;
  const objectPath = `/objects/${wildcardPath}`;

  if (!objectPathPattern.test(objectPath)) {
    res.status(404).json({ error: "Изображение не найдено." });
    return;
  }

  const [appearance] = await db
    .select({ backgroundImagePath: questStoreAppearanceTable.backgroundImagePath })
    .from(questStoreAppearanceTable)
    .where(eq(questStoreAppearanceTable.id, 1))
    .limit(1);

  const [publishedAnnouncement] = await db
    .select({ id: questStoreAnnouncementsTable.id })
    .from(questStoreAnnouncementsTable)
    .where(
      and(
        eq(questStoreAnnouncementsTable.published, true),
        or(
          eq(questStoreAnnouncementsTable.imagePath, objectPath),
          arrayContains(questStoreAnnouncementsTable.imagePaths, [objectPath]),
        ),
      ),
    )
    .limit(1);

  const [characterImage] = await db
    .select({ id: questCharactersTable.id })
    .from(questCharactersTable)
    .where(eq(questCharactersTable.imageUrl, objectPath))
    .limit(1);
  const [rewardImage] = await db
    .select({ id: questRewardsTable.id })
    .from(questRewardsTable)
    .where(eq(questRewardsTable.imageUrl, objectPath))
    .limit(1);

  if (
    appearance?.backgroundImagePath === objectPath ||
    publishedAnnouncement ||
    characterImage ||
    rewardImage
  ) {
    next();
    return;
  }

  requireAuthor(req, res, next);
};

router.get(
  "/storage/objects/*path",
  allowPublicStoreImagesOrRequireAuthor,
  async (req, res): Promise<void> => {
    const raw = req.params.path;
    const wildcardPath = Array.isArray(raw) ? raw.join("/") : raw;
    const objectPath = `/objects/${wildcardPath}`;

    try {
      const file = await objectStorage.getObjectEntityFile(objectPath);
      const response = await objectStorage.downloadObject(file);
      res.status(response.status);
      response.headers.forEach((value, key) => res.setHeader(key, value));

      if (response.body) {
        Readable.fromWeb(
          response.body as ReadableStream<Uint8Array>,
        ).pipe(res);
      } else {
        res.end();
      }
    } catch (error) {
      if (error instanceof ObjectNotFoundError) {
        res.status(404).json({ error: "Изображение не найдено." });
        return;
      }
      req.log.error({ err: error }, "Unable to serve stored image");
      res.status(500).json({ error: "Не удалось показать изображение." });
    }
  },
);

export default router;

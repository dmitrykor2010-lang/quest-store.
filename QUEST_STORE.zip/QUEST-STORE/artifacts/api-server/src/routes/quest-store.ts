import { clerkClient, getAuth } from "@clerk/express";
import {
  GetQuestStoreAdminResponse,
  GetQuestStoreResponse,
  UpdateQuestStoreBalanceBody,
  UpdateQuestStoreBalanceResponse,
  UpdateQuestStoreCharacterBody,
  UpdateQuestStoreCharacterParams,
  UpdateQuestStoreCharacterResponse,
  UpdateQuestStoreRewardBody,
  UpdateQuestStoreRewardParams,
  UpdateQuestStoreRewardResponse,
} from "@workspace/api-zod";
import {
  db,
  questCharactersTable,
  questRewardsTable,
  questStoreMetaTable,
} from "@workspace/db";
import { eq } from "drizzle-orm";
import {
  Router,
  type IRouter,
  type Request,
  type RequestHandler,
  type Response,
} from "express";
import { ObjectStorageService } from "../lib/objectStorage";

const router: IRouter = Router();
const objectStorage = new ObjectStorageService();
const storedImagePathPattern =
  /^\/objects\/uploads\/[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;

async function validateAndPrepareImage(
  req: Request,
  res: Response,
  imageUrl: string | null | undefined,
): Promise<boolean> {
  if (imageUrl === undefined || imageUrl === null) return true;

  if (storedImagePathPattern.test(imageUrl)) {
    const { userId } = getAuth(req);
    if (!userId) {
      res.status(401).json({ error: "Необходимо войти в аккаунт автора." });
      return false;
    }
    try {
      await objectStorage.trySetObjectEntityAclPolicy(imageUrl, {
        owner: userId,
        visibility: "public",
      });
      return true;
    } catch (error) {
      req.log.warn({ err: error }, "Quest image is missing from App Storage");
      res.status(400).json({
        error: "Изображение не найдено в постоянном хранилище.",
      });
      return false;
    }
  }

  try {
    const url = new URL(imageUrl);
    if (url.protocol === "http:" || url.protocol === "https:") return true;
  } catch {
    // Reject relative paths, executable schemes, and malformed URLs.
  }
  res.status(400).json({
    error: "Укажите ссылку HTTP(S) или сохранённое изображение App Storage.",
  });
  return false;
}

async function getSnapshot() {
  const [metaRows, characters, rewards] = await Promise.all([
    db.select().from(questStoreMetaTable).limit(1),
    db.select().from(questCharactersTable).orderBy(questCharactersTable.cost),
    db.select().from(questRewardsTable).orderBy(questRewardsTable.cost),
  ]);

  const meta = metaRows[0];
  if (!meta) {
    throw new Error("Quest store sample data has not been initialized.");
  }

  const updatedAt = [
    meta.updatedAt,
    ...characters.map((character) => character.updatedAt),
    ...rewards.map((reward) => reward.updatedAt),
  ].reduce((latest, date) => (date > latest ? date : latest), meta.updatedAt);

  return {
    points: meta.points,
    characters: characters.map(
      ({ id, name, description, cost, unlocked, imageUrl }) => ({
        id,
        name,
        description,
        cost,
        unlocked,
        imageUrl,
      }),
    ),
    rewards: rewards.map(({ id, name, description, cost, imageUrl }) => ({
      id,
      name,
      description,
      cost,
      imageUrl,
    })),
    updatedAt: updatedAt.toISOString(),
  };
}

export const requireAuthor: RequestHandler = async (req, res, next): Promise<void> => {
  const { userId } = getAuth(req);
  if (!userId) {
    res.status(401).json({ error: "Необходимо войти в аккаунт автора." });
    return;
  }

  const allowedEmail = process.env.QUEST_STORE_ADMIN_EMAIL
    ?.trim()
    .toLowerCase();
  if (!allowedEmail) {
    res.status(503).json({
      error: "Доступ автора ещё не настроен. Укажите почту автора в настройках приложения.",
    });
    return;
  }

  try {
    const user = await clerkClient.users.getUser(userId);
    const primaryEmail = user.emailAddresses.find(
      (email) => email.id === user.primaryEmailAddressId,
    );
    const isVerifiedAuthor =
      primaryEmail?.verification?.status === "verified" &&
      primaryEmail.emailAddress.trim().toLowerCase() === allowedEmail;

    if (!isVerifiedAuthor) {
      res.status(403).json({ error: "Панель доступна только автору магазина." });
      return;
    }

    next();
  } catch (error) {
    req.log.error({ error }, "Unable to verify QUEST STORE author");
    res.status(503).json({
      error: "Не удалось проверить доступ автора. Попробуйте ещё раз.",
    });
  }
};

export const requireSameOrigin: RequestHandler = (req, res, next): void => {
  const origin = req.get("origin");
  const forwardedHost = req.get("x-forwarded-host");
  const expectedHost =
    forwardedHost?.split(",")[0]?.trim() || req.get("host") || "";

  if (!origin || !expectedHost) {
    res.status(403).json({ error: "Недопустимый источник запроса." });
    return;
  }

  try {
    const originHost = new URL(origin).host.toLowerCase();
    if (originHost !== expectedHost.toLowerCase()) {
      res.status(403).json({ error: "Недопустимый источник запроса." });
      return;
    }
  } catch {
    res.status(403).json({ error: "Недопустимый источник запроса." });
    return;
  }

  next();
};

router.get("/quest-store", async (_req, res): Promise<void> => {
  const snapshot = await getSnapshot();
  res.json(GetQuestStoreResponse.parse(snapshot));
});

router.get(
  "/quest-store/admin",
  requireAuthor,
  async (_req, res): Promise<void> => {
    const snapshot = await getSnapshot();
    res.json(GetQuestStoreAdminResponse.parse(snapshot));
  },
);

router.patch(
  "/quest-store/admin/balance",
  requireSameOrigin,
  requireAuthor,
  async (req, res): Promise<void> => {
    const parsed = UpdateQuestStoreBalanceBody.safeParse(req.body);
    if (!parsed.success) {
      res.status(400).json({ error: parsed.error.message });
      return;
    }

    await db
      .insert(questStoreMetaTable)
      .values({ id: 1, points: parsed.data.points })
      .onConflictDoUpdate({
        target: questStoreMetaTable.id,
        set: { points: parsed.data.points, updatedAt: new Date() },
      });

    const snapshot = await getSnapshot();
    res.json(UpdateQuestStoreBalanceResponse.parse(snapshot));
  },
);

router.patch(
  "/quest-store/admin/characters/:id",
  requireSameOrigin,
  requireAuthor,
  async (req, res): Promise<void> => {
    const params = UpdateQuestStoreCharacterParams.safeParse(req.params);
    const body = UpdateQuestStoreCharacterBody.safeParse(req.body);
    if (!params.success) {
      res.status(400).json({ error: params.error.message });
      return;
    }
    if (!body.success) {
      res.status(400).json({ error: body.error?.message ?? "Invalid character data." });
      return;
    }
    if (!(await validateAndPrepareImage(req, res, body.data.imageUrl))) return;

    const [updated] = await db
      .update(questCharactersTable)
      .set({ ...body.data, updatedAt: new Date() })
      .where(eq(questCharactersTable.id, params.data.id))
      .returning({ id: questCharactersTable.id });

    if (!updated) {
      res.status(404).json({ error: "Персонаж не найден." });
      return;
    }

    const snapshot = await getSnapshot();
    res.json(UpdateQuestStoreCharacterResponse.parse(snapshot));
  },
);

router.patch(
  "/quest-store/admin/rewards/:id",
  requireSameOrigin,
  requireAuthor,
  async (req, res): Promise<void> => {
    const params = UpdateQuestStoreRewardParams.safeParse(req.params);
    const body = UpdateQuestStoreRewardBody.safeParse(req.body);
    if (!params.success) {
      res.status(400).json({ error: params.error.message });
      return;
    }
    if (!body.success) {
      res.status(400).json({ error: body.error?.message ?? "Invalid reward data." });
      return;
    }
    if (!(await validateAndPrepareImage(req, res, body.data.imageUrl))) return;

    const [updated] = await db
      .update(questRewardsTable)
      .set({ ...body.data, updatedAt: new Date() })
      .where(eq(questRewardsTable.id, params.data.id))
      .returning({ id: questRewardsTable.id });

    if (!updated) {
      res.status(404).json({ error: "Награда не найдена." });
      return;
    }

    const snapshot = await getSnapshot();
    res.json(UpdateQuestStoreRewardResponse.parse(snapshot));
  },
);

export default router;

import { randomUUID } from "node:crypto";
import { getAuth } from "@clerk/express";
import {
  CreateQuestStoreAnnouncementBody,
  CreateQuestStoreAnnouncementResponse,
  DeleteQuestStoreAnnouncementParams,
  DeleteQuestStoreAnnouncementResponse,
  GetQuestStoreAdminAnnouncementsResponse,
  GetQuestStoreAnnouncementsResponse,
  UpdateQuestStoreAnnouncementBody,
  UpdateQuestStoreAnnouncementParams,
  UpdateQuestStoreAnnouncementResponse,
} from "@workspace/api-zod";
import {
  db,
  questCharactersTable,
  questStoreAnnouncementsTable,
  questStoreAppearanceTable,
  questRewardsTable,
} from "@workspace/db";
import { and, arrayContains, desc, eq, ne, or } from "drizzle-orm";
import { Router, type IRouter } from "express";
import { ObjectStorageService } from "../lib/objectStorage";
import { requireAuthor, requireSameOrigin } from "./quest-store";

const router: IRouter = Router();
const objectStorage = new ObjectStorageService();

function toAnnouncement(row: typeof questStoreAnnouncementsTable.$inferSelect) {
  const imagePaths = row.imagePaths.length
    ? row.imagePaths
    : row.imagePath
      ? [row.imagePath]
      : [];
  return {
    id: row.id,
    title: row.title,
    body: row.body,
    imagePath: imagePaths[0] ?? null,
    imagePaths,
    published: row.published,
    createdAt: row.createdAt.toISOString(),
    updatedAt: row.updatedAt.toISOString(),
  };
}

async function setImageVisibility(
  imagePath: string,
  owner: string,
  visibility: "public" | "private",
): Promise<void> {
  await objectStorage.trySetObjectEntityAclPolicy(imagePath, {
    owner,
    visibility,
  });
}

async function makeImagePrivateIfUnused(
  imagePath: string | null,
  owner: string,
  excludingId?: string,
): Promise<void> {
  if (!imagePath) return;

  const imageReference = or(
    eq(questStoreAnnouncementsTable.imagePath, imagePath),
    arrayContains(questStoreAnnouncementsTable.imagePaths, [imagePath]),
  );
  const publishedImageFilter = excludingId
    ? and(
        imageReference,
        eq(questStoreAnnouncementsTable.published, true),
        ne(questStoreAnnouncementsTable.id, excludingId),
      )
    : and(imageReference, eq(questStoreAnnouncementsTable.published, true));
  const [otherPublishedReference] = await db
    .select({ id: questStoreAnnouncementsTable.id })
    .from(questStoreAnnouncementsTable)
    .where(publishedImageFilter)
    .limit(1);
  const [storeAppearance] = await db
    .select({
      backgroundImagePath: questStoreAppearanceTable.backgroundImagePath,
    })
    .from(questStoreAppearanceTable)
    .where(eq(questStoreAppearanceTable.id, 1))
    .limit(1);
  const [characterReference] = await db
    .select({ id: questCharactersTable.id })
    .from(questCharactersTable)
    .where(eq(questCharactersTable.imageUrl, imagePath))
    .limit(1);
  const [rewardReference] = await db
    .select({ id: questRewardsTable.id })
    .from(questRewardsTable)
    .where(eq(questRewardsTable.imageUrl, imagePath))
    .limit(1);
  if (
    otherPublishedReference ||
    storeAppearance?.backgroundImagePath === imagePath ||
    characterReference ||
    rewardReference
  ) {
    return;
  }

  try {
    await setImageVisibility(imagePath, owner, "private");
  } catch {
    // The database reference is already removed, and the storage route now
    // requires author access for this object even if metadata cleanup fails.
  }
}

router.get(
  "/quest-store/announcements",
  async (_req, res): Promise<void> => {
    const rows = await db
      .select()
      .from(questStoreAnnouncementsTable)
      .where(eq(questStoreAnnouncementsTable.published, true))
      .orderBy(desc(questStoreAnnouncementsTable.createdAt));
    res.json(GetQuestStoreAnnouncementsResponse.parse(rows.map(toAnnouncement)));
  },
);

router.get(
  "/quest-store/admin/announcements",
  requireAuthor,
  async (_req, res): Promise<void> => {
    const rows = await db
      .select()
      .from(questStoreAnnouncementsTable)
      .orderBy(desc(questStoreAnnouncementsTable.createdAt));
    res.json(
      GetQuestStoreAdminAnnouncementsResponse.parse(rows.map(toAnnouncement)),
    );
  },
);

router.post(
  "/quest-store/admin/announcements",
  requireSameOrigin,
  requireAuthor,
  async (req, res): Promise<void> => {
    const parsed = CreateQuestStoreAnnouncementBody.safeParse(req.body);
    if (!parsed.success) {
      res.status(400).json({ error: parsed.error.message });
      return;
    }
    if (!parsed.data.title.trim() || !parsed.data.body.trim()) {
      res.status(400).json({
        error: "Заголовок и текст объявления не могут быть пустыми.",
      });
      return;
    }
    const { userId } = getAuth(req);
    if (!userId) {
      res.status(401).json({ error: "Необходимо войти в аккаунт автора." });
      return;
    }

    const imagePaths = parsed.data.imagePaths !== undefined
      ? [...new Set(parsed.data.imagePaths)]
      : parsed.data.imagePath
        ? [parsed.data.imagePath]
        : [];
    if (imagePaths.length > 8) {
      res.status(400).json({ error: "Можно добавить не более 8 фотографий." });
      return;
    }
    for (const imagePath of imagePaths) {
      try {
        await setImageVisibility(
          imagePath,
          userId,
          parsed.data.published ? "public" : "private",
        );
      } catch (error) {
        req.log.warn({ err: error }, "Announcement image was not found");
        res.status(400).json({
          error: "Изображение не найдено в постоянном хранилище.",
        });
        return;
      }
    }

    const [created] = await db
      .insert(questStoreAnnouncementsTable)
      .values({
        id: randomUUID(),
        title: parsed.data.title.trim(),
        body: parsed.data.body.trim(),
        imagePath: imagePaths[0] ?? null,
        imagePaths,
        published: parsed.data.published,
      })
      .returning();

    res
      .status(201)
      .json(CreateQuestStoreAnnouncementResponse.parse(toAnnouncement(created)));
  },
);

router.patch(
  "/quest-store/admin/announcements/:id",
  requireSameOrigin,
  requireAuthor,
  async (req, res): Promise<void> => {
    const params = UpdateQuestStoreAnnouncementParams.safeParse(req.params);
    const parsed = UpdateQuestStoreAnnouncementBody.safeParse(req.body);
    if (!params.success) {
      res.status(400).json({ error: params.error.message });
      return;
    }
    if (!parsed.success) {
      res.status(400).json({ error: parsed.error.message });
      return;
    }
    if (Object.keys(parsed.data).length === 0) {
      res.status(400).json({ error: "Укажите хотя бы одно поле для изменения." });
      return;
    }
    if (
      (parsed.data.title !== undefined && !parsed.data.title.trim()) ||
      (parsed.data.body !== undefined && !parsed.data.body.trim())
    ) {
      res.status(400).json({
        error: "Заголовок и текст объявления не могут быть пустыми.",
      });
      return;
    }

    const [current] = await db
      .select()
      .from(questStoreAnnouncementsTable)
      .where(eq(questStoreAnnouncementsTable.id, params.data.id))
      .limit(1);
    if (!current) {
      res.status(404).json({ error: "Объявление не найдено." });
      return;
    }

    const { userId } = getAuth(req);
    if (!userId) {
      res.status(401).json({ error: "Необходимо войти в аккаунт автора." });
      return;
    }

    const currentImagePaths = current.imagePaths.length
      ? current.imagePaths
      : current.imagePath
        ? [current.imagePath]
        : [];
    const imagePathsProvided =
      parsed.data.imagePaths !== undefined ||
      parsed.data.imagePath !== undefined;
    const nextImagePaths = parsed.data.imagePaths !== undefined
      ? [...new Set(parsed.data.imagePaths)]
      : parsed.data.imagePath !== undefined
        ? parsed.data.imagePath
          ? [parsed.data.imagePath]
          : []
        : currentImagePaths;
    if (nextImagePaths.length > 8) {
      res.status(400).json({ error: "Можно добавить не более 8 фотографий." });
      return;
    }
    const nextPublished = parsed.data.published ?? current.published;
    const imageChanged =
      imagePathsProvided &&
      (currentImagePaths.length !== nextImagePaths.length ||
        currentImagePaths.some((path, index) => path !== nextImagePaths[index]));

    if (imageChanged || nextPublished !== current.published) {
      for (const imagePath of nextImagePaths) {
        try {
          await setImageVisibility(
            imagePath,
            userId,
            nextPublished ? "public" : "private",
          );
        } catch (error) {
          req.log.warn({ err: error }, "Announcement image was not found");
          res.status(400).json({
            error: "Изображение не найдено в постоянном хранилище.",
          });
          return;
        }
      }
    }

    const [updated] = await db
      .update(questStoreAnnouncementsTable)
      .set({
        ...(parsed.data.title !== undefined && {
          title: parsed.data.title.trim(),
        }),
        ...(parsed.data.body !== undefined && {
          body: parsed.data.body.trim(),
        }),
        ...(imagePathsProvided && {
          imagePath: nextImagePaths[0] ?? null,
          imagePaths: nextImagePaths,
        }),
        ...(parsed.data.published !== undefined && {
          published: parsed.data.published,
        }),
        updatedAt: new Date(),
      })
      .where(eq(questStoreAnnouncementsTable.id, params.data.id))
      .returning();

    if (!updated) {
      res.status(404).json({ error: "Объявление не найдено." });
      return;
    }

    for (const imagePath of currentImagePaths) {
      if (
        !nextImagePaths.includes(imagePath) ||
        (current.published && !nextPublished)
      ) {
        await makeImagePrivateIfUnused(imagePath, userId, current.id);
      }
    }

    res.json(
      UpdateQuestStoreAnnouncementResponse.parse(toAnnouncement(updated)),
    );
  },
);

router.delete(
  "/quest-store/admin/announcements/:id",
  requireSameOrigin,
  requireAuthor,
  async (req, res): Promise<void> => {
    const params = DeleteQuestStoreAnnouncementParams.safeParse(req.params);
    if (!params.success) {
      res.status(400).json({ error: params.error.message });
      return;
    }
    const { userId } = getAuth(req);
    if (!userId) {
      res.status(401).json({ error: "Необходимо войти в аккаунт автора." });
      return;
    }

    const [deleted] = await db
      .delete(questStoreAnnouncementsTable)
      .where(eq(questStoreAnnouncementsTable.id, params.data.id))
      .returning({
        id: questStoreAnnouncementsTable.id,
        imagePath: questStoreAnnouncementsTable.imagePath,
        imagePaths: questStoreAnnouncementsTable.imagePaths,
      });
    if (!deleted) {
      res.status(404).json({ error: "Объявление не найдено." });
      return;
    }

    const deletedImagePaths = deleted.imagePaths.length
      ? deleted.imagePaths
      : deleted.imagePath
        ? [deleted.imagePath]
        : [];
    for (const imagePath of deletedImagePaths) {
      await makeImagePrivateIfUnused(imagePath, userId, deleted.id);
    }
    res.json(DeleteQuestStoreAnnouncementResponse.parse({ deleted: true }));
  },
);

export default router;
